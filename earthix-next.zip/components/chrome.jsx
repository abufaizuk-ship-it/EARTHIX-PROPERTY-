"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { usePathname } from "next/navigation";
import { L } from "@/lib/nav";
import { L3, pick, tr, trEn } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { Icon, Logo, PMLogo, WhatsAppIcon, useFocusTrap } from "@/components/common";
import { warmFonts } from "@/lib/dom";
import { BRAND, IMG, LANGS, LANG_CODE, LANG_IDX, LANG_NAME } from "@/lib/brand";
import { CATEGORIES, waLink } from "@/lib/config";
import { svc, waText } from "@/lib/content";



// ---------- LOGO ----------

// ---------- NAVBAR ----------
export function NavbarInner({ settings, user, onLogout, onBook, savedCount }) {
  const { lang, setLang, t } = useLang();
  const [langOpen, setLangOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const setDom = (on) => { ["pm-drawer", "pm-scrim"].forEach((i) => { const el = document.getElementById(i); if (el) el.classList[on ? "add" : "remove"]("shown"); }); };
  const openMenu = useCallback(() => { setDom(true); setMenu(true); }, []);
  const closeMenu = useCallback(() => { setDom(false); setMenu(false); }, []);
  // tapping a menu item: the panel disappears at once (no slide-out) while the new page is already opening
  const closeNow = useCallback(() => {
    const ids = ["pm-drawer", "pm-scrim"];
    // inline style (not a class): React rewrites class names on re-render, but never touches this
    ids.forEach((i) => { const el = document.getElementById(i); if (el) { el.style.transition = "none"; el.classList.remove("shown"); } });
    setMenu(false);
    requestAnimationFrame(() => requestAnimationFrame(() => ids.forEach((i) => { const el = document.getElementById(i); if (el) el.style.transition = ""; })));
  }, []);
  const loggedIn = !!user;
  return (
    <>
    <header className="nav">
      <div className="wrap">
        <Logo />
        <div className="nav-r">
          <nav className="links" aria-label={tr("Primary")}>
            <a href={L("#/buy")}>{t("navBuy")}</a><a href={L("#/sell")}>{t("navSell")}</a>
            <a href={L("#/categories")}>{t("navCategories")}</a><a href={L("#/how-it-works")}>{t("navHow")}</a>
            <a href={L("#/tools")}>{tr("Tools")}</a><a href={L("#/about")}>{tr("About")}</a>
            <a href={L("#/contact")}>{t("navContact")}</a>
            <a className="btn btn-outline" style={{ height: 40 }} href={L(loggedIn ? "#/dashboard" : "#/login")}>{t(loggedIn ? "dashboard" : "login")}</a>
          </nav>
          <button type="button" className="langbtn" aria-label={t("language")} aria-expanded={langOpen} aria-haspopup="menu" onClick={() => { warmFonts(); setLangOpen((v) => !v); }}>
            <Icon name="globe" size={16} />{LANG_CODE[lang]}
          </button>
          {langOpen && (
            <div className="langmenu" role="menu">
              {LANGS.map((l) => (
                <button key={l} type="button" role="menuitem" lang={l} onClick={() => { setLangOpen(false); setLang(l); }}>{LANG_NAME[l]}</button>
              ))}
            </div>
          )}
          <button type="button" className="burger" aria-label={t("menu")} onClick={openMenu}><i /><i /><i /></button>
        </div>
      </div>
    </header>
    <Drawer open={menu} onClose={closeMenu} onNav={closeNow} settings={settings} user={user} onLogout={onLogout} onBook={onBook} savedCount={savedCount} />
    </>
  );
}

export const Navbar = React.memo(NavbarInner);


// ---------- DRAWER (hooks first; conditional return last) ----------
export function Drawer({ open, onClose, onNav, settings, user, onLogout, onBook, savedCount }) {
  const { lang, setLang, t } = useLang();
  const ref = useRef(null);
  useFocusTrap(open, ref, onClose);
  const shown = open;
  const lbl = (x) => { const m = x.match(/^(.*?)( \(\d+\))?$/); return trEn(m[1], lang) + (m[2] || ""); };
  const isAdmin = !!(user && user.role === "admin");
  const groups = [
    ["Explore", [["home", "#/", "Home"], ["shop", "#/buy", "Buy property"], ["users", "#/buy-request", "Share buy requirement"], ["rupee", "#/sell", "Sell property"], ["layers", "#/categories", "Categories"], ["heart", "#/saved", "Saved" + (savedCount ? " (" + savedCount + ")" : "")]]],
    ["Services", [["calendar", "book", "Book a meeting"], ["sparkle", "#/tools", "Unit converter & EMI"], ["pin", "#/track", "Track my request"], ["check", "#/how-it-works", "How it works"]]],
    ["Company", [["users", "#/about", "About us"], ["shield", "#/success-stories", "Success stories"], ["mail", "#/faq", "FAQ"], ["phone", "#/contact", "Contact"]]],
  ];
  const soc = settings.socials || {};
  return (
    <div>
      <div id="pm-scrim" className={"scrim fade" + (shown ? " shown" : "")} onPointerDown={onClose} aria-hidden="true" />
      <aside id="pm-drawer" aria-hidden={!open} className={"drawer" + (shown ? " shown" : "")} ref={ref} role="dialog" aria-modal="true" aria-label={t("menu")}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 8px 0 20px" }}>
          <b style={{ color: "var(--ink)" }}>{user ? (isAdmin ? trEn("Admin panel", lang) : trEn("Hello", lang) + (user.name ? ", " + user.name.split(" ")[0] : "")) : BRAND[LANG_IDX[lang]]}</b>
          <button type="button" className="burger" aria-label={t("close")} onClick={onClose}><Icon name="close" size={24} /></button>
        </div>
        {groups.map(([title, items]) => (
          <div key={title}>
            <h5>{trEn(title, lang)}</h5>
            {items.map(([ic, href, label]) => href === "book"
              ? <button key={label} type="button" className="item itembtn" onClick={() => { onNav(); onBook(); }}><Icon name={ic} />{lbl(label)}</button>
              : <a key={href} className="item" href={L(href)} onClick={onNav}><Icon name={ic} />{lbl(label)}</a>)}
          </div>
        ))}
        <h5>{t("language")}</h5>
        <div className="lsw">{LANGS.map((l) => <button key={l} type="button" lang={l} aria-pressed={lang === l} onClick={() => setLang(l)}>{LANG_NAME[l]}</button>)}</div>
        <div className="drawer-foot">
          <button type="button" className="btn btn-primary" onClick={() => { onClose(); onBook(); }}>{t("bookMeeting")}</button>
          <a className="btn btn-wa" href={L(waLink(settings.whatsapp, waText("general", {}, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{t("whatsapp")}</a>
          {user ? (
            <div style={{ display: "grid", gap: 10 }}>
              <a className="btn btn-primary" href={L(isAdmin ? "#/admin" : "#/dashboard")} onClick={onClose}>{isAdmin ? trEn("Admin panel", lang) : t("dashboard")}</a>
              <button type="button" className="btn btn-outline" onClick={() => { onClose(); onLogout(); }}>{trEn("Logout", lang)}</button>
            </div>
          ) : <a className="btn btn-outline" href={L("#/login")} onClick={onClose}>{trEn("Login / Register", lang)}</a>}
          <div>{pick(settings.address, lang)}</div>
          <div>{pick(settings.hours, lang)}</div>
          <div dir="ltr">{settings.phones.map((n) => <a key={n} href={L("tel:+91" + n)} style={{ marginInlineEnd: 10 }}>{n}</a>)}</div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>{[["Facebook", soc.facebook], ["Instagram", soc.instagram], ["YouTube", soc.youtube]].filter(([, u]) => u).map(([n, u]) => <a key={n} href={L(u)} target="_blank" rel="noopener noreferrer" style={{ color: "var(--teal)", fontWeight: 600 }}>{n}</a>)}</div>
          <div><a href={L("#/legal?tab=privacy")} onClick={onClose}>{tr("Privacy")}</a> · <a href={L("#/legal?tab=terms")} onClick={onClose}>{tr("Terms")}</a> · <a href={L("#/legal?tab=cookies")} onClick={onClose}>{tr("Cookies")}</a> · <a href={L("#/legal?tab=disclaimer")} onClick={onClose}>{tr("Disclaimer")}</a></div>
        </div>
      </aside>
    </div>
  );
}

// 3D coin-flip face (front + back, both upright) used by the footer logo.
function SpinFaces({ cls, uid }) {
  const one = (k, u) => (IMG.logo ? <img key={k} className={cls + " " + k} src={IMG.logo} alt="" draggable="false" /> : <span key={k} className={cls + " " + k}><PMLogo size={150} uid={u} /></span>);
  return [one("sf-front", uid + "a"), one("sf-back", uid + "b")];
}
// Footer emblem: spins (2 fast turns, easing to a stop) every time it scrolls into view and again on every page change.
function FooterSpinLogo() {
  const wrapRef = useRef(null);
  const pathname = usePathname();
  const [run, setRun] = useState(0);
  const armRef = useRef(true);
  const ioRef = useRef(null);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return undefined;
    armRef.current = true;
    const io = new IntersectionObserver((es) => {
      const e = es[es.length - 1];
      if (e.isIntersecting && e.intersectionRatio >= 0.6 && armRef.current) { armRef.current = false; setRun((n) => n + 1); }
      else if (e.intersectionRatio === 0) armRef.current = true;
    }, { threshold: [0, 0.6] });
    ioRef.current = io;
    io.observe(el);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    const el = wrapRef.current; const io = ioRef.current;
    if (!el || !io) return;
    armRef.current = true; io.unobserve(el); const id = requestAnimationFrame(() => io.observe(el));
    return () => cancelAnimationFrame(id);
  }, [pathname]);
  return (
    <div ref={wrapRef} className="fspin-wrap" aria-hidden="true">
      <div key={run} className={"fspin" + (run > 0 ? " go" : "")}><SpinFaces cls="fspin-face" uid="fs" /></div>
    </div>
  );
}
export function FooterInner({ settings }) {
  const { lang, t } = useLang();
  const rows = [["mail", settings.email], ["phone", settings.phones.join(" · ")], ["pin", pick(settings.address, lang)], ["clock", pick(settings.hours, lang)]];
  return (
    <footer style={{ background: "#fffaf3", borderTop: "1px solid var(--line)", padding: "40px 20px 96px" }}>
      <div className="wrap" style={{ padding: 0 }}>
        <Logo uid="f" /><p style={{ fontSize: 16 }}>{t("footTag")}</p>
        <p style={{ fontSize: 13.5, color: "var(--muted)", lineHeight: 1.6 }}>{L3(lang,
          BRAND[0] + " is a Saharsa property dealer helping families buy and sell farmland, plots, road-touch land, houses and shops in Simri Bakhtiyarpur, Sonbarsa, Mahishi, Kahara, Salkhua, Sour Bazar, Nauhatta, Patarghat, Banma Itahari, Sattar Kataiya and Saharsa town. Every listing is checked by our team, your details stay private, and our commission is told upfront.",
          BRAND[1] + " सहरसा का प्रॉपर्टी डीलर है, जो सिमरी बख्तियारपुर, सोनबरसा, महिषी, कहरा, सलखुआ, सौर बाज़ार, नौहट्टा, पतरघट, बनमा इटहरी, सत्तर कटैया और सहरसा शहर में कृषि भूमि, प्लॉट, रोड-टच ज़मीन, घर और दुकान की खरीद-बिक्री में परिवारों की मदद करता है। हर लिस्टिंग हमारी टीम जाँचती है, आपकी जानकारी निजी रहती है और कमीशन पहले बताया जाता है।",
          BRAND[2] + " سہرسا کا پراپرٹی ڈیلر ہے جو سمری بختیار پور، سونبرسا، مہشی، کہرا، سلکھوا، سور بازار، نوہٹا، پتر گھاٹ، بنما اٹہری، سترکٹیا اور سہرسا شہر میں زرعی زمین، پلاٹ، روڈ ٹچ زمین، گھر اور دکان کی خرید و فروخت میں خاندانوں کی مدد کرتا ہے۔ ہر لسٹنگ ہماری ٹیم جانچتی ہے، آپ کی معلومات نجی رہتی ہیں اور کمیشن پہلے بتایا جاتا ہے۔")}</p>
        {rows.map(([ic, txt]) => <div key={ic} style={{ display: "flex", gap: 12, alignItems: "center", margin: "10px 0" }}><span className="tile" style={{ width: 36, height: 36, borderRadius: 10, background: "#FFEAD2" }}><Icon name={ic} size={18} /></span><span dir={ic === "phone" || ic === "mail" || ic === "globe" ? "ltr" : undefined}>{txt}</span></div>)}
        <a href={L(settings.map)} target="_blank" rel="noopener noreferrer" style={{ color: "var(--teal)", fontWeight: 600 }}>{tr("Get Directions")} ↗</a>
        <div className="fcols">
          <div><h4>{tr("PROPERTIES")}</h4>{CATEGORIES.slice(0, 6).map((c) => <a key={c.slug} href={L("#/buy/" + c.slug)}>{c.name[LANG_IDX[lang]]}</a>)}</div>
          <div><h4>{tr("COMPANY")}</h4>{[["About", "about"], ["How It Works", "how-it-works"], ["Tools", "tools"], ["Contact", "contact"], ["FAQ", "faq"], ["Admin", "admin"]].map(([n, h]) => <a key={h} href={L("#/" + h)}>{tr(n)}</a>)}</div>
        </div>
        <FooterMore settings={settings} />
        <FooterSpinLogo />
        <p style={{ textAlign: "center", fontSize: 13, color: "var(--muted)", borderTop: "1px solid var(--line)", paddingTop: 16 }}>© 2026 {BRAND[LANG_IDX[lang] ?? 0]}. {tr("All rights reserved.")}<br /><a href={L("#/legal?tab=terms")} className="flink">{tr("Terms")}</a> | <a href={L("#/legal?tab=privacy")} className="flink">{tr("Privacy")}</a> | <a href={L("#/legal?tab=cookies")} className="flink">{tr("Cookies")}</a><br />{tr("Photos: Unsplash / Pexels")}</p>
      </div>
    </footer>
  );
}

export function FloatingInner({ settings }) {
  const { lang } = useLang();
  const [top, setTop] = useState(false);
  useEffect(() => { const f = () => setTop(window.scrollY > 600); window.addEventListener("scroll", f, { passive: true }); return () => window.removeEventListener("scroll", f); }, []);
  return (
    <div>
      {top && <button type="button" className="totop" aria-label={tr("Back to top")} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}><Icon name="arrow" size={18} className="arrup" /></button>}
      <a className="fab" href={L(waLink(settings.whatsapp, waText("general", {}, lang)))} target="_blank" rel="noopener noreferrer" aria-label={tr("WhatsApp")}><WhatsAppIcon size={28} /></a>
    </div>
  );
}

export function FooterMore({ settings }) {
  const { lang } = useLang();
  const soc = settings.socials || {};
  const circles = [["WhatsApp", waLink(settings.whatsapp, waText("general", {}, lang)), "#25d366", <WhatsAppIcon size={20} key="w" />], ["YouTube", soc.youtube, "#e02020", "▶"], ["Facebook", soc.facebook, "#1877f2", "f"], ["Instagram", soc.instagram, "linear-gradient(45deg,#f58529,#dd2a7b,#8134af)", "IG"]].filter((c) => c[1]);
  return (
    <div>
      <div style={{ display: "flex", gap: 10, margin: "20px 0" }}>{circles.map(([n, u, bg, ic]) => <a key={n} href={L(u)} target="_blank" rel="noopener noreferrer" aria-label={n} className="soc" style={{ background: bg }}>{ic}</a>)}</div>
      <div className="fcols">
        <div><h4>{tr("RESOURCES")}</h4>{[["Track My Request", "#/track"], ["Book a Meeting", "#/book-meeting"], ["Privacy", "#/legal?tab=privacy"], ["Terms", "#/legal?tab=terms"], ["Cookies", "#/legal?tab=cookies"], ["Disclaimer", "#/legal?tab=disclaimer"]].map(([n, h]) => <a key={h} href={L(h)}>{tr(n)}</a>)}</div>
        <div><h4>{tr("STAY UPDATED")}</h4><p style={{ fontSize: 15, margin: "0 0 10px" }}>{tr("Get new listings and tips in your inbox.")}</p>{["Private & secure", svc("badge"), "Free meeting booking"].map((x) => <div key={x} className="bul" style={{ fontSize: 13 }}><span className="tick"><Icon name="check" size={14} /></span>{tr(x)}</div>)}</div>
      </div>
    </div>
  );
}

export const Footer = React.memo(FooterInner);


export const Floating = React.memo(FloatingInner);
