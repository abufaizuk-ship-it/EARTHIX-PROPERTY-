import { NextResponse } from "next/server";

const LOCALES = ["en", "hi", "ur"];
const DEFAULT_LOCALE = "en";
const LOCALE_COOKIE = "pm_lang";

function pickLocale(request) {
  const c = request.cookies.get(LOCALE_COOKIE);
  if (c && LOCALES.indexOf(c.value) !== -1) return c.value;
  const al = (request.headers.get("accept-language") || "").toLowerCase();
  for (const part of al.split(",")) {
    const code = part.trim().slice(0, 2);
    if (LOCALES.indexOf(code) !== -1) return code;
  }
  return DEFAULT_LOCALE;
}

// / -> /en (or the visitor's saved / browser language), /buy -> /en/buy, /admin -> /en/admin
export function middleware(request) {
  const { pathname } = request.nextUrl;
  const first = pathname.split("/")[1];
  if (LOCALES.indexOf(first) === -1) {
    const url = request.nextUrl.clone();
    url.pathname = "/" + pickLocale(request) + (pathname === "/" ? "" : pathname);
    return NextResponse.redirect(url);
  }
  const res = NextResponse.next();
  res.cookies.set(LOCALE_COOKIE, first, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  return res;
}

export const config = {
  // Everything except API routes, Next internals, static files (anything with a dot), sitemap and robots.
  matcher: ["/((?!api|_next|sitemap.xml|robots.txt|.*\\..*).*)"],
};
