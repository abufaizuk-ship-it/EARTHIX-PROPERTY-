# Earthix Property

Private, broker-facilitated property matchmaking site (Bihar). English / हिन्दी / اردو (RTL), real URLs per language, Supabase backend, deployed on Vercel.

- **Stack:** Next.js 14 (App Router, JavaScript) · Tailwind · Supabase (Postgres + Auth, plain REST, no client library) · Cloudflare Turnstile (invisible) · Vercel
- **Founders:** Abuzar Gaffari, Abu Faiz. Earthix Property is the site brand.

## URLs

| Path | What |
|---|---|
| `/en` `/hi` `/ur` | Home (`/` redirects by cookie / browser language; Urdu is RTL) |
| `/[locale]/buy`, `/buy/[category]`, `/property/[id]` | Listings and property page |
| `/[locale]/sell` `rent` `contact` `about` `faq` `track` `saved` `book-meeting` ... | Content pages |
| `/en/admin/login` | Admin panel (`/admin` redirects to `/en/admin`) |
| `/sitemap.xml` `/robots.txt` | Generated (categories and properties x 3 languages) |

## Setup

### 1. Supabase
1. Create a **new** project (do not reuse another site's project).
2. SQL Editor: paste `supabase/schema.sql` → Run (once). Then paste `supabase/seed.sql` → Run (12 sample properties, 9 reviews; edit or delete them later in admin).
3. Project Settings → API: copy Project URL and the **anon** key. Never use or share the `service_role` / secret key.

### 2. First admin
1. Authentication → Users → Add user → email + password, tick *Auto Confirm User*.
2. SQL Editor: `update public.profiles set role = 'admin' where email = 'YOUR@EMAIL';`
3. Open `/en/admin/login` and sign in.

### 3. Email OTP (visitors and admin OTP)
1. Authentication → Email Templates → Magic Link: show the code, e.g. `<h2>Your Earthix code</h2><p>Code: <b>{{ .Token }}</b></p>`. OTP length 6.
2. Authentication → URL Configuration: Site URL = your production URL.
3. Built-in email is limited to a few mails per hour. Set custom SMTP (Gmail App Password or Resend) under Authentication → Emails → SMTP Settings. Paste the App Password without spaces. If mail does not arrive: Logs → Auth.

### 4. Cloudflare Turnstile
dash.cloudflare.com → Turnstile → Add site (your domain + `localhost`) → copy site key and secret key. Widget mode: **Managed / invisible**. If `TURNSTILE_SECRET_KEY` is NOT set, the server skips verification (fail-open), so always set it in production.

### 5. Environment variables
Copy `.env.example` to `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
NEXT_PUBLIC_SITE_URL=            # https://yourdomain (no trailing slash)
NEXT_PUBLIC_TURNSTILE_SITE_KEY=
TURNSTILE_SECRET_KEY=
```
Local run: `npm install` → `npm run dev`. Without Supabase keys the site runs in local-preview mode (data in the browser only).

### 6. GitHub + Vercel
1. Upload the project to a new GitHub repo (repo root = this folder's contents).
2. vercel.com → Add New → Project → import repo (Next.js auto-detected).
3. Add the five env vars (Production + Preview) → Deploy.
4. Settings → Domains: add your domain, then set `NEXT_PUBLIC_SITE_URL` to it and redeploy. Submit `/sitemap.xml` in Google Search Console.

## Security model
- Browser holds only the anon key. All tables have RLS. Public writes go through RPCs; they pass `/api/submit` first (same-origin check, per-IP rate limit, Turnstile) and are rate-limited again in Postgres.
- Admin = `profiles.role = 'admin'` (SQL only), enforced by RLS via `is_admin()`.
- Backup import never restores a session.

## Notes
- Site name is **Earthix Property**. Address and phones are editable in Admin → Settings.
- Domain default is the placeholder `earthixproperty.in` until `NEXT_PUBLIC_SITE_URL` is set.
- Logo is the "E" SVG in `app/icon.svg`; replace with your own.
- Written and checked (esbuild, server-render of all pages in 3 languages, local PostgreSQL test of schema) without npm access, so `next build` has **not** been run. On first `npm install && npm run build`, fix anything the compiler reports, then test: home in 3 languages, a property page, meeting booking, enquiry, admin login → edit property.
