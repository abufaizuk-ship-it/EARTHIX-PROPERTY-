-- =====================================================================================
-- Earthix Property (Saharsa, Bihar) - Supabase / Postgres schema
-- Paste the whole file into the Supabase SQL editor and press Run. Safe to re-run.
--
-- Security model
--   * RLS is enabled on every table. Visitors (anon) can only read PUBLIC content
--     (site_json, visible properties, visible reviews) and call the RPC functions.
--   * All visitor writes go through SECURITY DEFINER functions that validate input
--     and rate-limit. Nothing here needs or uses the service_role key.
--   * Admin = a row in public.profiles with role = 'admin' (set only via SQL, see end).
-- =====================================================================================

-- ---------- 0. Housekeeping: no implicit access for anyone ----------
-- (Supabase grants broad default privileges to anon/authenticated; we re-grant only what is needed below.)

-- ===================================================================================
-- 1. PROFILES  (one row per auth user; role can only be changed with SQL by the owner)
-- ===================================================================================
create table if not exists public.profiles (
  id         uuid primary key references auth.users (id) on delete cascade,
  email      text,
  role       text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- Create a profile automatically for every new auth user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, lower(new.email))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Back-fill profiles for users that existed before this script ran.
insert into public.profiles (id, email)
select u.id, lower(u.email) from auth.users u
on conflict (id) do nothing;

-- is_admin(): true when the caller's JWT user has profiles.role = 'admin'.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select p.role = 'admin' from public.profiles p where p.id = auth.uid()),
    false
  );
$$;

-- ===================================================================================
-- 2. PUBLIC CONTENT: site_json, properties, reviews
-- ===================================================================================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create table if not exists public.site_json (
  key        text primary key,                       -- 'settings' | 'locations'
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.properties (
  id         text primary key,
  visible    boolean not null default true,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.reviews (
  id         text primary key,
  visible    boolean not null default true,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.site_json  enable row level security;
alter table public.properties enable row level security;
alter table public.reviews    enable row level security;

drop trigger if exists trg_site_json_updated  on public.site_json;
create trigger trg_site_json_updated  before insert or update on public.site_json  for each row execute function public.set_updated_at();
drop trigger if exists trg_properties_updated on public.properties;
create trigger trg_properties_updated before insert or update on public.properties for each row execute function public.set_updated_at();
drop trigger if exists trg_reviews_updated    on public.reviews;
create trigger trg_reviews_updated    before insert or update on public.reviews    for each row execute function public.set_updated_at();

-- ===================================================================================
-- 3. PRIVATE DATA TABLES (written only through the RPC functions in section 5)
-- ===================================================================================
create table if not exists public.requests (
  id          text primary key,
  type        text not null check (type in ('buy', 'sell')),
  name        text not null,
  mobile      text not null,
  status      int  not null default 0,
  commission  numeric,
  follow_up   text,
  admin_notes text not null default '',
  data        jsonb not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists requests_created_idx on public.requests (created_at desc);
create index if not exists requests_mobile_idx  on public.requests (mobile);
alter table public.requests enable row level security;
drop trigger if exists trg_requests_updated on public.requests;
create trigger trg_requests_updated before update on public.requests for each row execute function public.set_updated_at();

create table if not exists public.meetings (
  id          text primary key,
  purpose     text not null,
  name        text not null,
  mobile      text not null,
  email       text,
  meet_date   date not null,
  slot        text not null,
  bring_later boolean not null default false,
  status      int  not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists meetings_slot_idx    on public.meetings (meet_date, slot);
create index if not exists meetings_created_idx on public.meetings (created_at desc);
alter table public.meetings enable row level security;

create table if not exists public.messages (
  id         bigint generated always as identity primary key,
  name       text not null,
  mobile     text not null,
  message    text not null,
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;

create table if not exists public.subscribers (
  id         bigint generated always as identity primary key,
  email      text not null unique,
  created_at timestamptz not null default now()
);
alter table public.subscribers enable row level security;

create table if not exists public.enquiries (
  id             text primary key,
  property_id    text,
  property_title text,
  name           text not null,
  mobile         text not null,
  email          text,
  message        text not null default '',
  status         int  not null default 0,
  created_at     timestamptz not null default now()
);
create index if not exists enquiries_created_idx on public.enquiries (created_at desc);
alter table public.enquiries enable row level security;

-- Rate-limit hits. RLS on with NO policies: only rate_limit_hit() (security definer) touches it.
create table if not exists public.rate_limits (
  id     bigint generated always as identity primary key,
  key    text not null,
  hit_at timestamptz not null default now()
);
create index if not exists rate_limits_key_idx on public.rate_limits (key, hit_at);
create index if not exists rate_limits_at_idx  on public.rate_limits (hit_at);
alter table public.rate_limits enable row level security;

-- ===================================================================================
-- 4. TABLE PRIVILEGES + RLS POLICIES
-- ===================================================================================
revoke all on public.profiles, public.site_json, public.properties, public.reviews,
              public.requests, public.meetings, public.messages, public.subscribers,
              public.enquiries, public.rate_limits
  from public, anon, authenticated;

-- anon: public content only
grant select on public.site_json, public.properties, public.reviews to anon;

-- authenticated: what RLS below will filter
grant select on public.profiles to authenticated;
grant select, insert, update, delete on public.site_json, public.properties, public.reviews to authenticated;
grant select, update, delete on public.requests, public.meetings, public.enquiries to authenticated;
grant select, delete on public.messages, public.subscribers to authenticated;
-- (no insert on private tables: visitors insert through RPC only; no grant at all on rate_limits)

-- profiles: a user can read only their own row. No INSERT/UPDATE/DELETE policy => role cannot be self-promoted.
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated
  using (id = (select auth.uid()));

-- site_json
drop policy if exists site_json_public_read on public.site_json;
create policy site_json_public_read on public.site_json for select to anon, authenticated using (true);
drop policy if exists site_json_admin_ins on public.site_json;
create policy site_json_admin_ins on public.site_json for insert to authenticated with check ((select public.is_admin()));
drop policy if exists site_json_admin_upd on public.site_json;
create policy site_json_admin_upd on public.site_json for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists site_json_admin_del on public.site_json;
create policy site_json_admin_del on public.site_json for delete to authenticated using ((select public.is_admin()));

-- properties and reviews: public sees visible rows; admin sees and changes everything
drop policy if exists properties_public_read on public.properties;
create policy properties_public_read on public.properties for select to anon, authenticated using (visible = true);
drop policy if exists properties_admin_sel on public.properties;
create policy properties_admin_sel on public.properties for select to authenticated using ((select public.is_admin()));
drop policy if exists properties_admin_ins on public.properties;
create policy properties_admin_ins on public.properties for insert to authenticated with check ((select public.is_admin()));
drop policy if exists properties_admin_upd on public.properties;
create policy properties_admin_upd on public.properties for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists properties_admin_del on public.properties;
create policy properties_admin_del on public.properties for delete to authenticated using ((select public.is_admin()));

drop policy if exists reviews_public_read on public.reviews;
create policy reviews_public_read on public.reviews for select to anon, authenticated using (visible = true);
drop policy if exists reviews_admin_sel on public.reviews;
create policy reviews_admin_sel on public.reviews for select to authenticated using ((select public.is_admin()));
drop policy if exists reviews_admin_ins on public.reviews;
create policy reviews_admin_ins on public.reviews for insert to authenticated with check ((select public.is_admin()));
drop policy if exists reviews_admin_upd on public.reviews;
create policy reviews_admin_upd on public.reviews for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists reviews_admin_del on public.reviews;
create policy reviews_admin_del on public.reviews for delete to authenticated using ((select public.is_admin()));

-- requests / meetings / enquiries: admin everything (except insert); a logged-in user sees rows with their own e-mail
drop policy if exists requests_admin_sel on public.requests;
create policy requests_admin_sel on public.requests for select to authenticated using ((select public.is_admin()));
drop policy if exists requests_own_sel on public.requests;
create policy requests_own_sel on public.requests for select to authenticated
  using (data->>'email' is not null and lower(data->>'email') = lower((select auth.jwt()) ->> 'email'));
drop policy if exists requests_admin_upd on public.requests;
create policy requests_admin_upd on public.requests for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists requests_admin_del on public.requests;
create policy requests_admin_del on public.requests for delete to authenticated using ((select public.is_admin()));

drop policy if exists meetings_admin_sel on public.meetings;
create policy meetings_admin_sel on public.meetings for select to authenticated using ((select public.is_admin()));
drop policy if exists meetings_own_sel on public.meetings;
create policy meetings_own_sel on public.meetings for select to authenticated
  using (email is not null and lower(email) = lower((select auth.jwt()) ->> 'email'));
drop policy if exists meetings_admin_upd on public.meetings;
create policy meetings_admin_upd on public.meetings for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists meetings_admin_del on public.meetings;
create policy meetings_admin_del on public.meetings for delete to authenticated using ((select public.is_admin()));

drop policy if exists enquiries_admin_sel on public.enquiries;
create policy enquiries_admin_sel on public.enquiries for select to authenticated using ((select public.is_admin()));
drop policy if exists enquiries_own_sel on public.enquiries;
create policy enquiries_own_sel on public.enquiries for select to authenticated
  using (email is not null and lower(email) = lower((select auth.jwt()) ->> 'email'));
drop policy if exists enquiries_admin_upd on public.enquiries;
create policy enquiries_admin_upd on public.enquiries for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists enquiries_admin_del on public.enquiries;
create policy enquiries_admin_del on public.enquiries for delete to authenticated using ((select public.is_admin()));

-- messages / subscribers: admin read + delete only
drop policy if exists messages_admin_sel on public.messages;
create policy messages_admin_sel on public.messages for select to authenticated using ((select public.is_admin()));
drop policy if exists messages_admin_del on public.messages;
create policy messages_admin_del on public.messages for delete to authenticated using ((select public.is_admin()));
drop policy if exists subscribers_admin_sel on public.subscribers;
create policy subscribers_admin_sel on public.subscribers for select to authenticated using ((select public.is_admin()));
drop policy if exists subscribers_admin_del on public.subscribers;
create policy subscribers_admin_del on public.subscribers for delete to authenticated using ((select public.is_admin()));

-- ===================================================================================
-- 5. RATE LIMITING
-- ===================================================================================
-- rate_limit_hit: true = allowed (hit recorded), false = over the limit (nothing recorded).
-- Callable by anon (the Next.js API route uses it for per-IP limits).
create or replace function public.rate_limit_hit(p_key text, p_max int, p_window_seconds int)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  n int;
  w int;
begin
  if p_key is null or length(p_key) = 0 or length(p_key) > 256 or p_max is null or p_max < 1 then
    return false;
  end if;
  w := least(greatest(coalesce(p_window_seconds, 60), 1), 86400);

  -- serialise concurrent hits on the same key so the count cannot be raced past
  perform pg_advisory_xact_lock(hashtextextended('rl:' || p_key, 0));

  select count(*) into n from public.rate_limits
   where key = p_key and hit_at > now() - make_interval(secs => w);
  if n >= p_max then
    return false;
  end if;

  insert into public.rate_limits (key) values (p_key);

  -- lazy purge of anything older than a day (about 1 call in 50)
  if random() < 0.02 then
    delete from public.rate_limits where hit_at < now() - interval '1 day';
  end if;
  return true;
end;
$$;

-- Internal helper: raise 'rate_limit' when the limit is exceeded.
create or replace function public.rl_enforce(p_key text, p_max int, p_window_seconds int)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.rate_limit_hit(p_key, p_max, p_window_seconds) then
    raise exception 'rate_limit';
  end if;
end;
$$;

-- ===================================================================================
-- 6. VALIDATION HELPERS (internal, not callable from the API)
-- ===================================================================================
create or replace function public.v_name(p text) returns text
language plpgsql immutable set search_path = public as $$
declare t text := btrim(coalesce(p, ''));
begin
  if char_length(t) < 2 or char_length(t) > 100 then raise exception 'invalid_name'; end if;
  return t;
end; $$;

create or replace function public.v_mobile(p text) returns text
language plpgsql immutable set search_path = public as $$
declare t text := btrim(coalesce(p, ''));
begin
  if t !~ '^[6-9][0-9]{9}$' then raise exception 'invalid_mobile'; end if;
  return t;
end; $$;

-- optional e-mail: null/empty -> null; otherwise validated and lower-cased
create or replace function public.v_email_opt(p text) returns text
language plpgsql immutable set search_path = public as $$
declare t text := lower(btrim(coalesce(p, '')));
begin
  if t = '' then return null; end if;
  if char_length(t) > 254 or t !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then raise exception 'invalid_email'; end if;
  return t;
end; $$;

-- the 30-minute slots the booking UI offers (MT_SLOTS in lib/forms.js: 10:00 AM .. 05:30 PM)
create or replace function public.v_slot_ok(p text) returns boolean
language sql immutable set search_path = public as $$
  select p = any (array['10:00 AM','10:30 AM','11:00 AM','11:30 AM','12:00 PM','12:30 PM',
                        '01:00 PM','01:30 PM','02:00 PM','02:30 PM','03:00 PM','03:30 PM',
                        '04:00 PM','04:30 PM','05:00 PM','05:30 PM']);
$$;

-- ===================================================================================
-- 7. PUBLIC RPC FUNCTIONS (SECURITY DEFINER; parameter names = JSON keys sent by the app)
--    Errors are plain strings: rate_limit, slot_full, sunday, past_date, invalid_date,
--    invalid_mobile, invalid_name, invalid_email, invalid_message, invalid_slot,
--    too_large, duplicate_id
-- ===================================================================================

-- 7.1 newsletter
create or replace function public.subscribe(p_email text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare e text := public.v_email_opt(p_email);
begin
  if e is null then raise exception 'invalid_email'; end if;
  perform public.rl_enforce('sub:' || e, 3, 3600);
  insert into public.subscribers (email) values (e) on conflict (email) do nothing;
  return true;
end;
$$;

-- 7.2 meeting booking
create or replace function public.book_meeting(
  p_id text, p_purpose text, p_name text, p_mobile text, p_email text,
  p_date text, p_slot text, p_bring_later boolean)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id      text := btrim(coalesce(p_id, ''));
  v_name    text := public.v_name(p_name);
  v_mobile  text := public.v_mobile(p_mobile);
  v_email   text := public.v_email_opt(p_email);
  v_date    date;
  v_today   date := (now() at time zone 'Asia/Kolkata')::date;
  v_slot    text := btrim(coalesce(p_slot, ''));
  v_purpose text := btrim(coalesce(p_purpose, ''));
  v_used    int;
begin
  if v_id = '' then v_id := 'MTG-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 10)); end if;
  if char_length(v_id) > 64 then raise exception 'too_large'; end if;
  if v_purpose not in ('buy', 'sell', 'visit', 'consult') then raise exception 'invalid_message'; end if;

  if p_date is null or p_date !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'invalid_date'; end if;
  begin
    v_date := p_date::date;
  exception when others then
    raise exception 'invalid_date';
  end;
  if v_date < v_today then raise exception 'past_date'; end if;
  if extract(dow from v_date) = 0 then raise exception 'sunday'; end if;
  if not public.v_slot_ok(v_slot) then raise exception 'invalid_slot'; end if;

  perform public.rl_enforce('mt:' || v_mobile, 5, 600);

  -- serialise bookings per date+slot so capacity (2) cannot be exceeded by parallel requests
  perform pg_advisory_xact_lock(hashtextextended('slot:' || v_date::text || '|' || v_slot, 0));
  select count(*) into v_used from public.meetings where meet_date = v_date and slot = v_slot;
  if v_used >= 2 then raise exception 'slot_full'; end if;

  begin
    insert into public.meetings (id, purpose, name, mobile, email, meet_date, slot, bring_later)
    values (v_id, v_purpose, v_name, v_mobile, v_email, v_date, v_slot, coalesce(p_bring_later, false));
  exception when unique_violation then
    raise exception 'duplicate_id';
  end;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

-- 7.3 buy / sell request
create or replace function public.submit_request(p_data jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_type   text;
  v_id     text;
  v_name   text;
  v_mobile text;
  v_email  text;
  v_data   jsonb;
begin
  if p_data is null or jsonb_typeof(p_data) <> 'object' then raise exception 'invalid_message'; end if;
  if octet_length(p_data::text) > 200000 then raise exception 'too_large'; end if;

  v_type := p_data->>'type';
  if v_type is null or v_type not in ('buy', 'sell') then raise exception 'invalid_message'; end if;
  v_name   := public.v_name(p_data->>'name');
  v_mobile := public.v_mobile(p_data->>'mobile');
  v_email  := public.v_email_opt(p_data->>'email');
  v_id     := btrim(coalesce(p_data->>'id', ''));
  if v_id = '' then v_id := 'REQ-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 10)); end if;
  if char_length(v_id) > 64 then raise exception 'too_large'; end if;

  perform public.rl_enforce('req:' || v_mobile, 5, 600);

  -- keep the payload intact; only drop admin-owned fields a visitor must not set (they live in real columns)
  v_data := (p_data - 'status' - 'commission' - 'followUp' - 'adminNotes' - 'at')
            || jsonb_build_object('id', v_id, 'type', v_type, 'name', v_name, 'mobile', v_mobile);
  if v_email is not null then v_data := v_data || jsonb_build_object('email', v_email); end if;

  begin
    insert into public.requests (id, type, name, mobile, data)
    values (v_id, v_type, v_name, v_mobile, v_data);
  exception when unique_violation then
    raise exception 'duplicate_id';
  end;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

-- 7.4 contact message
create or replace function public.send_message(p_name text, p_mobile text, p_message text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name text := public.v_name(p_name);
  v_mobile text := public.v_mobile(p_mobile);
  v_msg text := btrim(coalesce(p_message, ''));
begin
  if char_length(v_msg) < 3 or char_length(v_msg) > 2000 then raise exception 'invalid_message'; end if;
  perform public.rl_enforce('msg:' || v_mobile, 5, 600);
  insert into public.messages (name, mobile, message) values (v_name, v_mobile, v_msg);
  return true;
end;
$$;

-- 7.5 property enquiry (message is optional in the UI)
create or replace function public.send_enquiry(
  p_id text, p_property_id text, p_property_title text, p_name text,
  p_mobile text, p_email text, p_message text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id     text := btrim(coalesce(p_id, ''));
  v_name   text := public.v_name(p_name);
  v_mobile text := public.v_mobile(p_mobile);
  v_email  text := public.v_email_opt(p_email);
  v_msg    text := btrim(coalesce(p_message, ''));
  v_pid    text := nullif(btrim(coalesce(p_property_id, '')), '');
  v_ptitle text := nullif(btrim(coalesce(p_property_title, '')), '');
begin
  if v_id = '' then v_id := 'ENQ-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 10)); end if;
  if char_length(v_id) > 64 or char_length(coalesce(v_pid, '')) > 100 or char_length(coalesce(v_ptitle, '')) > 300 then
    raise exception 'too_large';
  end if;
  if char_length(v_msg) > 2000 then raise exception 'invalid_message'; end if;
  perform public.rl_enforce('enq:' || v_mobile, 5, 600);
  begin
    insert into public.enquiries (id, property_id, property_title, name, mobile, email, message)
    values (v_id, v_pid, v_ptitle, v_name, v_mobile, v_email, v_msg);
  exception when unique_violation then
    raise exception 'duplicate_id';
  end;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

-- 7.6 visitor review: always stored hidden + pending until an admin approves it
create or replace function public.submit_review(p_data jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id     text;
  v_name   text;
  v_text   text;
  v_rating numeric;
  v_data   jsonb;
begin
  if p_data is null or jsonb_typeof(p_data) <> 'object' then raise exception 'invalid_message'; end if;
  if octet_length(p_data::text) > 20000 then raise exception 'too_large'; end if;

  v_name := public.v_name(p_data->>'name');
  if jsonb_typeof(p_data->'text') = 'array' then v_text := btrim(coalesce(p_data->'text'->>0, ''));
  else v_text := btrim(coalesce(p_data->>'text', '')); end if;
  if char_length(v_text) < 3 or char_length(v_text) > 2000 then raise exception 'invalid_message'; end if;

  if jsonb_typeof(p_data->'rating') <> 'number' then raise exception 'invalid_message'; end if;
  v_rating := (p_data->>'rating')::numeric;
  if v_rating < 1 or v_rating > 5 or v_rating <> trunc(v_rating) then raise exception 'invalid_message'; end if;

  v_id := btrim(coalesce(p_data->>'id', ''));
  if v_id = '' then v_id := 'RV-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 10)); end if;
  if char_length(v_id) > 64 then raise exception 'too_large'; end if;

  -- no caller IP is available here: a global cap plus a per-name cap
  perform public.rl_enforce('rv:all', 20, 3600);
  perform public.rl_enforce('rv:name:' || lower(v_name), 3, 3600);

  v_data := (p_data - 'helpful') || jsonb_build_object('id', v_id, 'name', v_name, 'helpful', 0, 'visible', false, 'pending', true);
  begin
    insert into public.reviews (id, visible, data) values (v_id, false, v_data);
  exception when unique_violation then
    raise exception 'duplicate_id';
  end;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

-- 7.7 status tracking: id AND mobile must both match. Returns {"status": n} or null.
create or replace function public.track_item(p_id text, p_mobile text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id text := upper(btrim(coalesce(p_id, '')));
  v_mobile text := btrim(coalesce(p_mobile, ''));
  s int;
begin
  if v_id = '' or char_length(v_id) > 64 or v_mobile = '' or char_length(v_mobile) > 20 then return null; end if;
  perform public.rl_enforce('trk:' || v_mobile, 10, 600);

  select status into s from public.requests where upper(id) = v_id and mobile = v_mobile limit 1;
  if found then return jsonb_build_object('status', s); end if;
  select status into s from public.meetings where upper(id) = v_id and mobile = v_mobile limit 1;
  if found then return jsonb_build_object('status', s); end if;
  select status into s from public.enquiries where upper(id) = v_id and mobile = v_mobile limit 1;
  if found then return jsonb_build_object('status', s); end if;
  return null;
end;
$$;

-- ===================================================================================
-- 8. FUNCTION PRIVILEGES: nothing by default, then exactly what the app calls
-- ===================================================================================
revoke all on function
  public.handle_new_user(), public.is_admin(), public.set_updated_at(),
  public.rate_limit_hit(text, int, int), public.rl_enforce(text, int, int),
  public.v_name(text), public.v_mobile(text), public.v_email_opt(text), public.v_slot_ok(text),
  public.subscribe(text),
  public.book_meeting(text, text, text, text, text, text, text, boolean),
  public.submit_request(jsonb), public.send_message(text, text, text),
  public.send_enquiry(text, text, text, text, text, text, text),
  public.submit_review(jsonb), public.track_item(text, text)
  from public, anon, authenticated;

grant execute on function
  public.is_admin(),
  public.rate_limit_hit(text, int, int),
  public.subscribe(text),
  public.book_meeting(text, text, text, text, text, text, text, boolean),
  public.submit_request(jsonb), public.send_message(text, text, text),
  public.send_enquiry(text, text, text, text, text, text, text),
  public.submit_review(jsonb), public.track_item(text, text)
  to anon, authenticated;

-- ===================================================================================
-- 9. MAKE THE FIRST ADMIN
--    1) Create the user (Supabase Dashboard > Authentication > Users > Add user, with a password).
--    2) Run (once), with your real e-mail:
--
--      update public.profiles set role = 'admin' where email = 'YOUR@EMAIL';
--
--    (profiles.email is stored lower-case.)
-- ===================================================================================
