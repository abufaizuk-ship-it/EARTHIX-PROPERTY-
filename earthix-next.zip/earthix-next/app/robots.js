import { SITE_URL } from "@/lib/config";

export default function robots() {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/en/admin", "/hi/admin", "/ur/admin", "/en/login", "/hi/login", "/ur/login", "/en/dashboard", "/hi/dashboard", "/ur/dashboard"] }],
    sitemap: SITE_URL + "/sitemap.xml",
    host: SITE_URL,
  };
}
