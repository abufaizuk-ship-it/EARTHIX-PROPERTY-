import { SITE_URL, CATEGORIES } from "@/lib/config";
import { LOCALES, localePath, languageAlternates } from "@/lib/seo";
import { fetchProperties } from "@/lib/server-data";

export const revalidate = 3600;

const STATIC_PATHS = ["", "/buy", "/sell", "/buy-request", "/categories", "/how-it-works", "/tools", "/track", "/success-stories", "/about", "/contact", "/faq", "/book-meeting",
  "/legal?tab=privacy", "/legal?tab=terms", "/legal?tab=disclaimer", "/legal?tab=cookies"];

const entry = (path, lastModified, changeFrequency, priority) =>
  LOCALES.map((l) => ({ url: SITE_URL + localePath(l, path), lastModified, changeFrequency, priority, alternates: { languages: languageAlternates(path) } }));

export default async function sitemap() {
  const now = new Date();
  const out = [];
  STATIC_PATHS.forEach((p) => out.push(...entry(p, now, p === "" || p === "/buy" ? "daily" : "monthly", p === "" ? 1 : p === "/buy" ? 0.9 : 0.6)));
  CATEGORIES.forEach((c) => out.push(...entry("/buy/" + c.slug, now, "weekly", 0.7)));
  try {
    const props = await fetchProperties();
    props.forEach((p) => out.push(...entry("/property/" + p.id, now, "weekly", 0.8)));
  } catch (e) { /* still serve the static part */ }
  return out;
}
