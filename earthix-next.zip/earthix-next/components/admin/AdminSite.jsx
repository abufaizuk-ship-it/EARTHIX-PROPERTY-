"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { BRAND, BRAND_DEFAULT, BRAND_TAG, BRAND_TAG_DEFAULT, LANGS, LANG_NAME } from "@/lib/brand";
import { Err, Field } from "@/components/common";
import { ImgPick } from "@/components/admin/AdminProps";
import { getFounder } from "@/lib/store";
import { SEED_REVIEWS, SHAYARI } from "@/lib/seed";
import { DOCS, PURPOSES } from "@/lib/forms";
import { CATEGORIES } from "@/lib/config";
import { PickBtn } from "@/components/forms";
import { rvRating } from "@/lib/content";
import { LOCATION_DATA } from "@/lib/locations";


export function AdminBrand({ settings, onSave }) {
  const b = settings.brand || {};
  const [names, setNames] = useState(() => [0, 1, 2].map((i) => (b.names && b.names[i]) || BRAND[i]));
  const [logo, setLogo] = useState(b.logo || "");
  const [tags, setTags] = useState(() => [0, 1, 2].map((i) => (b.tags && b.tags[i]) || BRAND_TAG[i]));
  const [err, setErr] = useState("");
  const save = (e) => {
    e.preventDefault();
    const n = names.map((x) => x.trim());
    if (n.some((x) => x.length < 2)) { setErr("Fill the website name in all three languages (at least 2 letters each)."); return; }
    setErr("");
    onSave({ brand: { names: n, logo, tags: tags.map((x) => x.trim()) } });
  };
  const reset = () => { setNames(BRAND_DEFAULT.slice()); setTags(BRAND_TAG_DEFAULT.slice()); setLogo(""); setErr(""); onSave({ brand: null }); };
  return (
    <form className="card" onSubmit={save} noValidate>
      <h3 className="ct" style={{ marginTop: 0 }}>Website name and logo</h3>
      <p className="hint">The name shows in the top bar, menu, footer, browser tab and WhatsApp messages. The logo replaces the orange badge everywhere.</p>
      <Field id="br-en" label="Website name (English)"><input id="br-en" className="inp" maxLength={40} value={names[0]} onChange={(e) => setNames((a) => [e.target.value, a[1], a[2]])} /></Field>
      <Field id="br-hi" label="Website name (हिन्दी)"><input id="br-hi" className="inp" maxLength={40} value={names[1]} onChange={(e) => setNames((a) => [a[0], e.target.value, a[2]])} /></Field>
      <Field id="br-ur" label="Website name (اردو)"><input id="br-ur" className="inp" dir="rtl" maxLength={40} value={names[2]} onChange={(e) => setNames((a) => [a[0], a[1], e.target.value])} /></Field>
      <Field id="bt-en" label="Line under the name (English)"><input id="bt-en" className="inp" maxLength={40} value={tags[0]} onChange={(e) => setTags((a) => [e.target.value, a[1], a[2]])} /></Field>
      <Field id="bt-hi" label="Line under the name (हिन्दी)"><input id="bt-hi" className="inp" maxLength={40} value={tags[1]} onChange={(e) => setTags((a) => [a[0], e.target.value, a[2]])} /></Field>
      <Field id="bt-ur" label="Line under the name (اردو)"><input id="bt-ur" className="inp" dir="rtl" maxLength={40} value={tags[2]} onChange={(e) => setTags((a) => [a[0], a[1], e.target.value])} /></Field>
      <ImgPick id="br-logo" label="Logo" hint="Square PNG with a transparent background works best (it is resized to 256 px)." value={logo} onChange={setLogo} max={256} mime="image/png" />
      <Err m={err} />
      <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Save brand</button>
      <button type="button" className="btn btn-outline" style={{ width: "100%", marginTop: 10 }} onClick={reset}>Reset to original name and logo</button>
    </form>
  );
}

export function AdminFounder({ settings, onSave }) {
  const F = getFounder(settings);
  const [name, setName] = useState(F.name.slice()), [role, setRole] = useState(F.role.slice()), [note, setNote] = useState(F.note.slice()), [photo, setPhoto] = useState(F.photo);
  const [err, setErr] = useState("");
  const up = (setter, i) => (e) => { const v = e.target.value; setter((a) => a.map((x, k) => (k === i ? v : x))); };
  const save = (e) => {
    e.preventDefault();
    if (name[0].trim().length < 2 || note[0].trim().length < 20) { setErr("Fill the English name and an English message (at least 20 letters). Empty Hindi/Urdu boxes will show the English text."); return; }
    setErr("");
    onSave({ founder: { name: name.map((x) => x.trim()), role: role.map((x) => x.trim()), note: note.map((x) => x.trim()), photo } });
  };
  const reset = () => { const d = getFounder(null); setName(d.name.slice()); setRole(d.role.slice()); setNote(d.note.slice()); setPhoto(""); setErr(""); onSave({ founder: null }); };
  const LN = [["English", 0], ["हिन्दी", 1], ["اردو", 2]];
  return (
    <form className="card" onSubmit={save} noValidate>
      <h3 className="ct" style={{ marginTop: 0 }}>Founder photo and message</h3>
      <p className="hint">Shown on the Home page and the About page.</p>
      <ImgPick id="fd-photo" label="Founder photo" hint="A clear portrait works best (it is resized to 900 px)." value={photo} onChange={setPhoto} max={900} mime="image/jpeg" round />
      {LN.map(([l, i]) => <Field key={"n" + i} id={"fd-n" + i} label={"Name (" + l + ")"}><input id={"fd-n" + i} className="inp" dir={i === 2 ? "rtl" : "ltr"} maxLength={60} value={name[i]} onChange={up(setName, i)} /></Field>)}
      {LN.map(([l, i]) => <Field key={"r" + i} id={"fd-r" + i} label={"Role (" + l + ")"}><input id={"fd-r" + i} className="inp" dir={i === 2 ? "rtl" : "ltr"} maxLength={80} value={role[i]} onChange={up(setRole, i)} /></Field>)}
      {LN.map(([l, i]) => <Field key={"m" + i} id={"fd-m" + i} label={"Message (" + l + ")"}><textarea id={"fd-m" + i} className="inp" style={{ height: 170, padding: 12 }} dir={i === 2 ? "rtl" : "ltr"} maxLength={900} value={note[i]} onChange={up(setNote, i)} /></Field>)}
      <Err m={err} />
      <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Save founder</button>
      <button type="button" className="btn btn-outline" style={{ width: "100%", marginTop: 10 }} onClick={reset}>Reset to original text</button>
    </form>
  );
}


export function AdminContent({ settings, onSave }) {
  const [slides, setSlides] = useState(() => [0, 1, 2, 3, 4].map((i) => (settings.heroSlides && settings.heroSlides[i]) || ""));
  const [cats, setCats] = useState(() => ({ ...(settings.catImages || {}) }));
  const flat = (l) => ((settings.shayari && settings.shayari[l]) || SHAYARI[l]).map((pr) => pr.join("\n")).join("\n");
  const [shay, setShay] = useState(() => ({ en: flat("en"), hi: flat("hi"), ur: flat("ur") }));
  const [docs, setDocs] = useState(() => { const o = {}; Object.keys(DOCS).forEach((k) => { o[k] = ((settings.docLists && settings.docLists[k]) || DOCS[k]).join("\n"); }); return o; });
  const save = (e) => {
    e.preventDefault();
    const sh = {};
    for (const l of LANGS) {
      const lines = shay[l].split("\n").map((x) => x.trim()).filter(Boolean);
      if (lines.length !== 6) { onSave(null, "Shayari (" + LANG_NAME[l] + ") needs exactly 6 lines: 3 pairs of 2 lines."); return; }
      sh[l] = [[lines[0], lines[1]], [lines[2], lines[3]], [lines[4], lines[5]]];
    }
    const dl = {};
    Object.keys(docs).forEach((k) => { dl[k] = docs[k].split("\n").map((x) => x.trim()).filter(Boolean); });
    onSave({ heroSlides: slides, catImages: cats, shayari: sh, docLists: dl });
  };
  return (
    <form className="card" onSubmit={save} noValidate>
      <h3 className="ct" style={{ marginTop: 0 }}>Hero slider photos (5 slides)</h3>
      <p className="hint">Upload a photo from your phone or computer, or paste an image link. Photos are resized automatically. Press "Save content" at the end.</p>
      {slides.map((v, i) => <ImgPick key={i} id={"ac-s" + i} label={"Slide " + (i + 1)} value={v} max={900} onChange={(u) => setSlides((a) => a.map((x, k) => (k === i ? u : x)))} />)}
      <h3 className="ct">Category photos</h3>
      {CATEGORIES.map((c) => <ImgPick key={c.slug} id={"ac-c-" + c.slug} label={c.name[0]} value={cats[c.slug] || ""} max={600} onChange={(u) => setCats((o) => ({ ...o, [c.slug]: u }))} />)}
      <h3 className="ct">Shayari (6 lines per language)</h3>
      {LANGS.map((l) => <Field key={l} id={"ac-sh-" + l} label={LANG_NAME[l]}><textarea id={"ac-sh-" + l} className="inp" style={{ height: 150, padding: 12 }} dir={l === "ur" ? "rtl" : "ltr"} value={shay[l]} onChange={(e) => setShay((o) => ({ ...o, [l]: e.target.value }))} /></Field>)}
      <h3 className="ct">Meeting document lists (one per line)</h3>
      {Object.keys(docs).map((k) => <Field key={k} id={"ac-d-" + k} label={PURPOSES.find((x) => x[0] === k)[1]}><textarea id={"ac-d-" + k} className="inp" style={{ height: 110, padding: 12 }} value={docs[k]} onChange={(e) => setDocs((o) => ({ ...o, [k]: e.target.value }))} /></Field>)}
      <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Save content</button>
    </form>
  );
}

export function AdminReviews({ db, commit, toast }) {
  const list = db.reviews || SEED_REVIEWS;
  const [f, setF] = useState({ name: "", role: "", text: "", rating: 5 }), [err, setErr] = useState("");
  const [replyFor, setReplyFor] = useState(null), [rp, setRp] = useState(["", "", ""]);
  const add = (e) => {
    e.preventDefault();
    if (f.name.trim().length < 2 || f.role.trim().length < 2 || f.text.trim().length < 10) { setErr("Fill name, role and a review of at least 10 characters."); return; }
    setErr("");
    commit((d) => { d.reviews = (d.reviews || SEED_REVIEWS.map((x) => ({ ...x }))).concat({ id: Date.now(), name: f.name.trim(), role: [f.role.trim()], text: [f.text.trim()], rating: Number(f.rating) || 5, at: Date.now(), helpful: 0, visible: true }); });
    toast("Review added"); setF({ name: "", role: "", text: "", rating: 5 });
  };
  const upd = (fn) => commit((d) => { d.reviews = fn(d.reviews || SEED_REVIEWS.map((x) => ({ ...x }))); });
  const patch = (id, p) => upd((a) => a.map((x) => (x.id === id ? { ...x, ...p } : x)));
  const openReply = (r) => { setReplyFor(r.id); setRp([0, 1, 2].map((i) => (r.reply && r.reply[i]) || "")); };
  const saveReply = (id) => { const arr = rp.map((x) => x.trim()); patch(id, { reply: arr.some(Boolean) ? [arr[0] || arr[1] || arr[2], arr[1] || arr[0] || arr[2], arr[2] || arr[0] || arr[1]] : null }); setReplyFor(null); toast("Reply saved"); };
  const pend = list.filter((r) => r.pending).length;
  return (
    <div>
      {pend > 0 && <div className="card" style={{ background: "#fff8e6", marginBottom: 12, padding: 14 }}><b>{pend} new review{pend > 1 ? "s" : ""} waiting for approval.</b> Tap Approve to show it on the website.</div>}
      <form className="card" onSubmit={add} noValidate style={{ marginBottom: 16 }}>
        <h3 className="ct" style={{ marginTop: 0 }}>Add review</h3>
        <Field id="ar-name" label="Name"><input id="ar-name" placeholder="e.g. Rahul Kumar" className="inp" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field id="ar-role" label="Role, place"><input id="ar-role" placeholder="e.g. Farmer, Salkhua" className="inp" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })} /></Field>
        <Field id="ar-rate" label="Rating"><PickBtn id="ar-rate" noSearch title="Rating" value={String(f.rating)} onChange={(v) => setF({ ...f, rating: v })} options={[5, 4, 3, 2, 1].map((n) => ({ v: String(n), l: n + " ★" }))} /></Field>
        <Field id="ar-text" label="Review"><textarea id="ar-text" placeholder="e.g. They explained everything before we met." className="inp" style={{ height: 90, padding: 12 }} value={f.text} onChange={(e) => setF({ ...f, text: e.target.value })} /></Field>
        <Err m={err} /><button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Add review</button>
      </form>
      {list.map((r) => (
        <div className="card" key={r.id} style={{ marginBottom: 12, opacity: r.visible === false && !r.pending ? 0.55 : 1 }}>
          <b>{r.name}</b> · {(r.role && r.role[0]) || ""} · <span style={{ color: "var(--gold)" }}>{"★".repeat(rvRating(r))}</span>{r.pending && <span className="mini" style={{ marginInlineStart: 8, background: "#fff1cf", color: "#7A4B00" }}>Pending</span>}
          <p className="cb">{r.text[0]}</p>
          {r.reply && <p className="cb" style={{ background: "var(--teal-soft)", borderRadius: 10, padding: 10 }}><b>Owner reply:</b> {r.reply[0]}</p>}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {r.pending && <button type="button" className="btn btn-primary" style={{ height: 40 }} onClick={() => patch(r.id, { pending: false, visible: true })}>Approve</button>}
            {!r.pending && <button type="button" className="btn btn-outline" style={{ height: 40 }} onClick={() => patch(r.id, { visible: r.visible === false })}>{r.visible === false ? "Show" : "Hide"}</button>}
            <PickBtn noSearch title="Rating" style={{ height: 40, width: 92 }} value={String(rvRating(r))} onChange={(v) => patch(r.id, { rating: Number(v) })} options={[5, 4, 3, 2, 1].map((n) => ({ v: String(n), l: n + " ★" }))} />
            <button type="button" className="btn btn-outline" style={{ height: 40 }} onClick={() => (replyFor === r.id ? setReplyFor(null) : openReply(r))}>{r.reply ? "Edit reply" : "Reply"}</button>
            <button type="button" className="btn btn-outline" style={{ height: 40, color: "var(--error)", borderColor: "var(--error)" }} onClick={() => { if (window.confirm("Delete this review?")) upd((a) => a.filter((x) => x.id !== r.id)); }}>Delete</button>
          </div>
          {replyFor === r.id && (
            <div style={{ marginTop: 12 }}>
              {[["English", 0], ["हिन्दी", 1], ["اردو", 2]].map(([l, i]) => <Field key={i} id={"rp-" + r.id + i} label={"Reply (" + l + ")"}><textarea id={"rp-" + r.id + i} className="inp" style={{ height: 70, padding: 12 }} dir={i === 2 ? "rtl" : "ltr"} value={rp[i]} onChange={(e) => setRp((a) => a.map((x, k) => (k === i ? e.target.value : x)))} /></Field>)}
              <button type="button" className="btn btn-primary" style={{ width: "100%" }} onClick={() => saveReply(r.id)}>Save reply</button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export function AdminLocations({ db, commit, toast }) {
  const [txt, setTxt] = useState(""), [msg, setMsg] = useState("");
  const loc = db.locations || {};
  const villageCount = (dist) => Object.keys(loc[dist] || {}).reduce((n, bl) => n + Object.keys(loc[dist][bl]).reduce((m, pa) => m + loc[dist][bl][pa].length, 0), 0);
  const doImport = () => {
    const rows = txt.split("\n").map((l) => l.split(/[\t,]/).map((x) => x.trim())).filter((r) => r.some(Boolean));
    if (rows.length && /^district$/i.test(rows[0][0])) rows.shift();
    const next = JSON.parse(JSON.stringify(loc)); let ok = 0; const bad = [];
    rows.forEach((r, k) => {
      const dKey = Object.keys(LOCATION_DATA).find((x) => x.toLowerCase() === (r[0] || "").toLowerCase());
      const bKey = dKey && LOCATION_DATA[dKey].find((x) => x.toLowerCase() === (r[1] || "").toLowerCase());
      if (!dKey || !bKey || r.length < 4 || !r[2] || !r[3]) { bad.push(k + 1); return; }
      next[dKey] = next[dKey] || {}; next[dKey][bKey] = next[dKey][bKey] || {};
      const arr = (next[dKey][bKey][r[2]] = next[dKey][bKey][r[2]] || []);
      if (!arr.includes(r[3])) { arr.push(r[3]); ok++; }
    });
    const skipped = bad.length ? " Skipped rows: " + bad.slice(0, 8).join(", ") + (bad.length > 8 ? "…" : "") + "." : "";
    if (!ok) { setMsg("Nothing imported. Each row must be: District, Block, Panchayat, Village, and District/Block must match the verified list." + skipped); return; }
    commit((d) => { d.locations = next; });
    setMsg("Imported " + ok + " villages." + skipped); setTxt(""); toast("Locations saved");
  };
  return (
    <div className="card">
      <h3 className="ct" style={{ marginTop: 0 }}>Panchayat & Village lists</h3>
      <p className="cb" style={{ fontSize: 13 }}>No dummy data is bundled. Paste official rows (from the Local Government Directory or Bihar land records): <b>District, Block, Panchayat, Village</b>, one per line. Rows whose District or Block is not in the verified list are skipped.</p>
      {Object.keys(LOCATION_DATA).map((x) => <div key={x} style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}><span>{x}</span><b>{villageCount(x)} villages</b></div>)}
      <label className="lbl" htmlFor="lc-box">Paste rows</label>
      <textarea id="lc-box" className="inp" dir="ltr" style={{ height: 160, padding: 12 }} placeholder="Saharsa, Kahara, <Panchayat>, <Village>" value={txt} onChange={(e) => setTxt(e.target.value)} />
      {msg && <p className="cb" style={{ fontSize: 13 }}>{msg}</p>}
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        <button type="button" className="btn btn-primary" style={{ flex: 1 }} onClick={doImport}>Import</button>
        <button type="button" className="btn btn-outline" onClick={() => { if (window.confirm("Remove all loaded Panchayat and Village data?")) commit((d) => { d.locations = null; }); }}>Clear</button>
      </div>
    </div>
  );
}
