"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { allProps, getDb, saveDb } from "@/lib/store";
import { NAV, navigate, L } from "@/lib/nav";
import { EMAIL_RE, fmtINR } from "@/lib/helpers";
import { REMOTE, friendlyAuth, fromMeeting, fromReq, rest, sbSendOtp, sbVerifyOtp } from "@/lib/backend";
import { maskEmail, waText } from "@/lib/content";
import { T, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { Err, Field, PageHead, WhatsAppIcon } from "@/components/common";
import { STAGES, detailLines, ex } from "@/lib/forms";
import { catName, waLink } from "@/lib/config";
import { PropertyCard } from "@/components/property";


export function LoginPage({ onLogin, toast }) {
  const [step, setStep] = useState(0);
  const [email, setEmail] = useState(""), [name, setName] = useState(""), [otp, setOtp] = useState(""), [ok, setOk] = useState(false), [err, setErr] = useState("");
  const [left, setLeft] = useState(0), [tries, setTries] = useState(0), [lock, setLock] = useState(0), [busy, setBusy] = useState(false);
  const em = email.trim().toLowerCase();
  useEffect(() => { const s = getDb().session; if (s && s.role === "user") { navigate("#/", true); } }, []);
  useEffect(() => {
    if (left <= 0) return undefined;
    const id = setTimeout(() => setLeft((v) => v - 1), 1000);
    return () => clearTimeout(id);
  }, [left]);
  const send = (e) => {
    if (e) e.preventDefault();
    if (!EMAIL_RE.test(em)) { setErr("Enter a valid email address."); return; }
    if (!ok) { setErr("Please accept the Terms and Privacy notice."); return; }
    setErr(""); setOtp("");
    if (!REMOTE) { setStep(1); setLeft(30); toast("Demo mode: no email is sent. Use OTP 123456."); return; }
    setBusy(true);
    sbSendOtp(em).then(() => { setBusy(false); setStep(1); setLeft(60); toast("OTP sent to " + maskEmail(em)); }).catch((er) => { setBusy(false); setErr(friendlyAuth(er)); });
  };
  const wrong = (msg) => {
    const n = tries + 1; setTries(n);
    if (n >= 5) { setLock(Date.now() + 300000); setTries(0); setErr("Too many wrong attempts. Locked for 5 minutes."); } else setErr(msg(n));
  };
  const verify = (e) => {
    e.preventDefault();
    if (Date.now() < lock) { setErr("Too many wrong attempts. Please wait a few minutes."); return; }
    if (otp.length < 6) { setErr("Enter the 6-digit OTP from your email."); return; }
    if (!REMOTE) {
      if (otp !== "123456") { wrong((n) => "Wrong OTP. " + (5 - n) + " tries left."); return; }
      complete(); return;
    }
    setBusy(true);
    sbVerifyOtp(em, otp).then(() => { setBusy(false); complete(); }).catch((er) => { setBusy(false); wrong(() => friendlyAuth(er)); });
  };
  const complete = () => {
    const db = getDb();
    const nm = name.trim();
    const users = db.users || [];
    const known = users.find((u) => u.email === em);
    db.users = known ? users.map((u) => (u.email === em ? { ...u, name: nm || u.name, lastLogin: Date.now() } : u)) : users.concat({ email: em, name: nm, createdAt: Date.now(), lastLogin: Date.now() });
    db.session = { email: em, role: "user", name: nm || (known && known.name) || "", at: Date.now() };
    if (!saveDb(db).ok) toast(T.storageFull[0]);
    onLogin(); toast("Logged in"); navigate("#/");
  };
  return (
    <div className="wrap" style={{ maxWidth: 420, paddingBottom: 48 }}>
      <PageHead pill="Login" plain="" hl="Welcome back." sub="Login with your email and a one-time code to see your buy and sell requests, meetings and saved properties." />
      {!REMOTE && <div className="card" style={{ background: "#fff8e6", marginBottom: 12, padding: 14, fontSize: 13 }}>{tr("Demo mode: no email is sent and the OTP is 123456. Add your Supabase keys and turn on email OTP to send real codes.")}</div>}
      {step === 0 ? (
        <form className="card" onSubmit={send} noValidate>
          <Field id="l-email" label={tr("Email address")}><input id="l-email" className="inp" type="email" dir="ltr" inputMode="email" autoComplete="email" autoCapitalize="none" spellCheck="false" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field id="l-name" label={tr("Your name (optional)")}><input id="l-name" placeholder={ex("name")} className="inp" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <label className="chk"><input id="l-consent" type="checkbox" checked={ok} onChange={(e) => setOk(e.target.checked)} /><span>{tr("I agree to the")} <a href={L("#/legal?tab=terms")} style={{ textDecoration: "underline" }}>{tr("Terms")}</a> {tr("and")} <a href={L("#/legal?tab=privacy")} style={{ textDecoration: "underline" }}>{tr("Privacy notice")}</a>.</span></label>
          <Err m={err} />
          <button type="submit" disabled={busy} className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{busy ? "Sending..." : "Send OTP to email"}</button>
        </form>
      ) : (
        <form className="card" onSubmit={verify} noValidate>
          <p className="cb" style={{ marginTop: 0 }}>{tr("We sent a one-time code to")} <b dir="ltr">{maskEmail(em)}</b>. {tr("Check your Inbox and Spam folder.")}{!REMOTE && <> {tr("Demo mode: enter")} <b dir="ltr">123456</b>.</>}</p>
          <Field id="l-otp" label={tr("OTP")}><input id="l-otp" placeholder={ex("otp")} className="inp otp" dir="ltr" inputMode="numeric" autoComplete="one-time-code" maxLength={8} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} /></Field>
          <Err m={err} />
          <button type="submit" disabled={busy} className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{busy ? "Checking..." : "Verify & login"}</button>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 14 }}>
            <button type="button" className="btn btn-link" style={{ height: 44 }} onClick={() => { setStep(0); setErr(""); setOtp(""); }}>{tr("Change email")}</button>
            <button type="button" className="btn btn-link" style={{ height: 44 }} disabled={left > 0 || busy} onClick={() => send()}>{left > 0 ? "Resend in " + left + "s" : "Resend OTP"}</button>
          </div>
        </form>
      )}
      <p style={{ textAlign: "center", fontSize: 13 }}>{tr("Staff?")} <a href={L("#/admin")} style={{ color: "var(--teal)", fontWeight: 600 }}>{tr("Admin login")}</a></p>
    </div>
  );
}


export function RequestHistoryCard({ r }) {
  const { lang } = useLang();
  const buy = r.type === "buy";
  const place = [r.village, r.panchayat, r.block, r.district].filter(Boolean).join(", ");
  const st = Math.min(Math.max(Number(r.status) || 0, 0), STAGES.length - 1);
  const lines = detailLines(r.category, r.details, buy ? "buy" : "sell", "en");
  const when = r.at ? new Date(r.at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "";
  const lo = Number(r.budgetMin) > 0 ? fmtINR(Number(r.budgetMin)) : "", hi = Number(r.budgetMax) > 0 ? fmtINR(Number(r.budgetMax)) : "";
  const money = buy ? (lo && hi ? lo + " to " + hi : hi ? "Up to " + hi : lo ? "From " + lo : "") : (Number(r.price) > 0 ? fmtINR(Number(r.price)) : "");
  const size = buy ? [r.areaMin, r.areaMax].filter(Boolean).join(" to ") : (r.area || "");
  const facts = [size ? "Size: " + size + " " + (r.unit || "") : "", money ? (buy ? "Budget: " : "Expected price: ") + money : "", buy && r.purpose ? "For: " + r.purpose : "", buy && r.timeline ? "Timeline: " + r.timeline : "", buy && r.funding ? "Payment: " + r.funding : ""].filter(Boolean);
  return (
    <div className="card reqh">
      <div className="reqh-top"><span className={"rtype " + (buy ? "b" : "s")}>{buy ? "BUY" : "SELL"}</span><b dir="ltr">{r.id}</b><span className="rdate">{when}</span></div>
      <h3 className="ct" style={{ margin: "10px 0 4px" }}>{catName(r.category, "en")}</h3>
      {place && <p className="cb" style={{ margin: "0 0 8px" }}>{place}</p>}
      {facts.length > 0 && <div className="rrow">{facts.map((x) => <span key={x}>{x}</span>)}</div>}
      <div className="rprog" role="img" aria-label={"Status: " + STAGES[st]}>{STAGES.map((s, k) => <i key={s} className={k <= st ? "on" : ""} />)}</div>
      <p className="rstage">{tr("Status:")} <b>{tr(STAGES[st])}</b></p>
      {lines.length > 0 && <details className="rdet"><summary>{buy ? "Your preferences" : "Property details"} ({lines.length})</summary><ul>{lines.map((x) => <li key={x}>{x}</li>)}</ul></details>}
      {r.notes ? <p className="cb" style={{ fontStyle: "italic" }}>“{r.notes}”</p> : null}
      <div className="stack"><a className="btn btn-outline" href={L("#/track")}>{tr("Track request")}</a><a className="btn btn-wa" href={L(waLink(getDb().settings.whatsapp, waText(buy ? "buy" : "sell", r, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{tr("WhatsApp")}</a></div>
    </div>
  );
}


export function DashboardPage({ db, saved, toggle, onLogout }) {
  const [tab, setTab] = useState("req");
  const [mine, setMine] = useState(null);
  const s = db.session;
  const who = s ? (s.email || s.mobile || "") : "";
  useEffect(() => {
    if (!REMOTE || !who) return undefined;
    let dead = false;
    Promise.all([rest("requests", "select=*&order=created_at.desc"), rest("meetings", "select=*&order=created_at.desc")]).then(([a, b]) => { if (!dead) setMine({ requests: a.map(fromReq), meetings: b.map(fromMeeting) }); }).catch(() => {});
    return () => { dead = true; };
  }, [who]);
  if (!s) return <LoginRedirect />;
  const mail = (s.email || "").toLowerCase(), mob = s.mobile || "";
  const isMine = (r) => (mail && ((r.acct || "").toLowerCase() === mail || String(r.email || "").toLowerCase() === mail)) || (mob && r.mobile === mob);
  const byNew = (a, b) => (b.at || 0) - (a.at || 0);
  const reqs = (mine ? mine.requests : (db.requests || []).filter(isMine)).slice().sort(byNew);
  const mts = (mine ? mine.meetings : (db.meetings || []).filter(isMine)).slice().sort(byNew);
  const buys = reqs.filter((r) => r.type === "buy"), sells = reqs.filter((r) => r.type !== "buy");
  const list = allProps().filter((p) => saved.includes(p.id));
  const profile = (db.users || []).find((u) => (mail && u.email === mail) || (mob && u.mobile === mob)) || {};
  const tabs = [["req", "All requests (" + reqs.length + ")"], ["buy", "Buy history (" + buys.length + ")"], ["sell", "Sell history (" + sells.length + ")"], ["mt", "Meetings (" + mts.length + ")"], ["sv", "Saved (" + list.length + ")"], ["pf", "Profile"]];
  const empty = (txt, links) => <div className="card">{txt}<div className="stack" style={{ marginTop: 12 }}>{links}</div></div>;
  const showReqs = (arr, txt) => (arr.length ? arr.map((r) => <RequestHistoryCard key={r.id} r={r} />) : empty(txt, <><a className="btn btn-primary" href={L("#/buy-request")}>{tr("Share a buy requirement")}</a><a className="btn btn-outline" href={L("#/sell")}>{tr("Submit a sell request")}</a></>));
  return (
    <div className="wrap" style={{ paddingBottom: 48 }}>
      <PageHead pill="Dashboard" plain="Your " hl="dashboard." sub={tr("Signed in as") + " " + (s.email || s.mobile || "")} />
      <div className="dstats">{[["buy", buys.length, "Buy requests"], ["sell", sells.length, "Sell requests"], ["mt", mts.length, "Meetings"]].map(([k, n, l]) => <button key={k} type="button" className="dstat" onClick={() => setTab(k)}><b>{n}</b><span>{l}</span></button>)}</div>
      <div className="chiprow" style={{ marginBottom: 16 }}>{tabs.map(([k, l]) => <button key={k} type="button" className="areachip" aria-pressed={tab === k} style={tab === k ? { background: "var(--teal-soft)", cursor: "pointer", fontWeight: 700 } : { cursor: "pointer" }} onClick={() => setTab(k)}>{l}</button>)}</div>
      {tab === "req" && showReqs(reqs, "No requests yet.")}
      {tab === "buy" && showReqs(buys, "No buy requests yet. Tell us what you want to buy and we will match it privately.")}
      {tab === "sell" && showReqs(sells, "No sell requests yet.")}
      {tab === "mt" && (mts.length ? mts.map((r) => <div className="card" key={r.id} style={{ marginBottom: 12 }}><b dir="ltr">{r.id}</b><p className="cb">{r.date} · {r.slot} · {r.purpose}</p></div>) : <div className="card">{tr("No meetings yet.")}</div>)}
      {tab === "sv" && (list.length ? <div className="grid pgrid">{list.map((p) => <PropertyCard key={p.id} p={p} saved onToggleSave={toggle} />)}</div> : <div className="card">{tr("Nothing saved yet.")}</div>)}
      {tab === "pf" && <div className="card"><p className="cb" dir="ltr" style={{ marginTop: 0 }}>Email: {s.email || "-"}</p>{(s.name || profile.name) && <p className="cb">Name: {s.name || profile.name}</p>}{mob && <p className="cb" dir="ltr">Mobile: {mob}</p>}{profile.createdAt && <p className="cb">Member since: {new Date(profile.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</p>}<button type="button" className="btn btn-outline" onClick={onLogout}>Logout</button></div>}
    </div>
  );
}


export function LoginRedirect() { useEffect(() => { navigate("#/login", true); }, []); return null; }
