"use client";

import React, { useEffect } from "react";
import { useApp } from "@/components/AppProvider";
import { BackBar, NotFound } from "@/components/common";
import { Home } from "@/components/home";
import { BuyPage, DetailPage } from "@/components/property";
import { BuyRequestPage } from "@/components/forms";
import { SellPage } from "@/components/sell";
import { AboutPage, CategoriesPage, ContactPage, FaqPage, HowPage, LegalPage, SavedPage, ToolsPage, TrackPage } from "@/components/pages";
import { SuccessPage } from "@/components/reviews";
import { DashboardPage, LoginPage } from "@/components/account";
import { AdminPage } from "@/components/admin/AdminPage";
import { openMeeting } from "@/lib/dom";
import { sbLogout } from "@/lib/backend";
import { getDb, saveDb } from "@/lib/store";
import { navigate } from "@/lib/nav";

// Chooses the page for the URL (the old single-file app's page switch). `route` = { path, parts, params } comes from
// the server page, so the first HTML already contains the right page.
export default function PageRouter({ route }) {
  const { db, setDb, settings, saved, toggle, onBook, toast } = useApp();
  const p0 = route.parts[0];

  useEffect(() => {
    document.documentElement.setAttribute("data-page", p0 || "home");
    if (p0 === "book-meeting") openMeeting("consult");
  }, [p0]);

  let page;
  if (!p0 || p0 === "book-meeting") return <Home settings={settings} saved={saved} toggle={toggle} onBook={onBook} toast={toast} />;
  else if (p0 === "buy") page = <BuyPage key={route.parts[1] || "all"} route={route} saved={saved} toggle={toggle} />;
  else if (p0 === "property") page = <DetailPage id={route.parts[1]} settings={settings} saved={saved} toggle={toggle} onBook={onBook} toast={toast} />;
  else if (p0 === "buy-request") page = <BuyRequestPage settings={settings} toast={toast} />;
  else if (p0 === "sell") page = <SellPage settings={settings} toast={toast} />;
  else if (p0 === "track") page = <TrackPage />;
  else if (p0 === "tools") page = <ToolsPage settings={settings} />;
  else if (p0 === "admin") page = <AdminPage db={db} setDb={setDb} toast={toast} />;
  else if (p0 === "faq") page = <FaqPage />;
  else if (p0 === "legal") page = <LegalPage route={route} />;
  else if (p0 === "about") page = <AboutPage settings={settings} />;
  else if (p0 === "how-it-works") page = <HowPage route={route} />;
  else if (p0 === "categories") page = <CategoriesPage />;
  else if (p0 === "saved") page = <SavedPage saved={saved} toggle={toggle} />;
  else if (p0 === "contact") page = <ContactPage settings={settings} toast={toast} />;
  else if (p0 === "success-stories") page = <SuccessPage />;
  else if (p0 === "login") page = <LoginPage onLogin={() => setDb({ ...getDb() })} toast={toast} />;
  else if (p0 === "dashboard") page = <DashboardPage db={db} saved={saved} toggle={toggle} onLogout={() => { sbLogout(); const d = getDb(); d.session = null; saveDb(d); setDb({ ...d }); navigate("#/"); }} />;
  else page = <NotFound />;
  return <div className="pg"><BackBar />{page}</div>;
}
