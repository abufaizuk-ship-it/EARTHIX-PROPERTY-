"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L } from "@/lib/nav";
import { pick, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { BRAND, IMG, LANG_IDX } from "@/lib/brand";
import { EMAIL_RE, MOBILE_RE, cleanMobile, isSunday, makeId, nextWorkingDay, pad2, ymdLocal } from "@/lib/helpers";
import { DOCS, DOC_NOTE, MT_CAP, MT_PARTS, MT_PURPOSE_ICON, MT_SLOTS, PURPOSES, ex, hint, mtBooked, mtDay, mtFmt, mtSlotState, parseYmd } from "@/lib/forms";
import { Err, Field, Icon, WhatsAppIcon, useFocusTrap } from "@/components/common";
import { acctEmail, getDb, saveDb } from "@/lib/store";
import { QUEUED_MSG, REMOTE, submitRemote } from "@/lib/backend";
import { HOURS, waLink } from "@/lib/config";
import { waText } from "@/lib/content";



export function MeetingModalInner({ settings, toast }) {
  const { lang, t } = useLang();
  const li = LANG_IDX[lang] ?? 0;
  const L = (en, hi, ur) => [en, hi, ur || en][li];
  const rtl = lang === "ur";
  const sgn = rtl ? -1 : 1;
  const numInp = rtl ? { textAlign: "right" } : undefined;
  const ref = useRef(null);
  const timeRef = useRef(null);
  const [open, setOpen] = useState(false);
  const blank = (purpose) => ({ purpose, name: "", mobile: "", email: "", date: nextWorkingDay(), slot: "", later: false, consent: false });
  const [f, setF] = useState(() => blank("buy"));
  const [err, setErr] = useState({});
  const [done, setDone] = useState(null);
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState(() => { const d = parseYmd(nextWorkingDay()); return { y: d.getFullYear(), m: d.getMonth() }; });
  const [part, setPart] = useState(0);
  const [drag, setDrag] = useState(0);
  const [slide, setSlide] = useState(0);
  const sw = useRef({ x: 0, y: 0, on: false, moved: false, lock: "" });
  const close = useCallback(() => { ["pm-mscrim", "pm-meeting"].forEach((id) => { const el = document.getElementById(id); if (el) el.classList.remove("shown"); }); setOpen(false); }, []);
  useFocusTrap(open, ref, close);
  const booked = useMemo(() => mtBooked(getDb().meetings), [open, done]);
  const now = new Date();
  const today = ymdLocal(now);
  const firstFreePart = (ymd) => { for (let p = 0; p < 3; p++) if (MT_SLOTS.some((s) => s.part === p && mtSlotState(ymd, s, booked, new Date()).st === "free")) return p; return 0; };
  useEffect(() => {
    const on = (e) => {
      const d0 = nextWorkingDay(); const d = parseYmd(d0);
      setF(blank(e.detail || "buy")); setErr({}); setDone(null);
      setView({ y: d.getFullYear(), m: d.getMonth() });
      setPart(0); setOpen(true);
    };
    window.addEventListener("pm-meeting", on);
    return () => window.removeEventListener("pm-meeting", on);
  }, []);
  useEffect(() => { if (open && !done) setPart(firstFreePart(f.date)); }, [open, f.date]);
  const up = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const pickDate = (ymd, scroll) => {
    const d = parseYmd(ymd);
    setSlide(0);
    setView({ y: d.getFullYear(), m: d.getMonth() });
    setF((s) => ({ ...s, date: ymd, slot: "" }));
    setErr((x) => ({ ...x, date: undefined, slot: undefined }));
    if (scroll) setTimeout(() => { if (timeRef.current && timeRef.current.scrollIntoView) timeRef.current.scrollIntoView({ behavior: "smooth", block: "start" }); }, 90);
  };
  const nextAvailable = () => {
    for (let i = 0; i < 120; i++) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
      const y = ymdLocal(d);
      if (mtDay(y, booked, now).free > 0) { pickDate(y, true); return; }
    }
  };
  const scrollErr = () => setTimeout(() => { const el = document.querySelector("#pm-meeting .err"); if (el && el.scrollIntoView) el.scrollIntoView({ block: "center", behavior: "smooth" }); }, 40);
  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (f.name.trim().length < 2) er.name = L("Enter your name.", "अपना नाम लिखें।", "اپنا نام لکھیں۔");
    if (!MOBILE_RE.test(f.mobile)) er.mobile = "Enter a valid 10-digit mobile number.";
    if (f.email && !EMAIL_RE.test(f.email)) er.email = "Enter a valid email.";
    if (!f.date || isSunday(f.date) || f.date < ymdLocal(new Date())) er.date = "Pick a working day (Mon–Sat), today or later.";
    else if (!f.slot) er.slot = L("Please pick a time slot.", "कृपया समय चुनें।", "براہ کرم وقت منتخب کریں۔");
    else {
      const si = MT_SLOTS.find((s) => s.v === f.slot);
      const st = si ? mtSlotState(f.date, si, mtBooked(getDb().meetings), new Date()).st : "booked";
      if (st === "past") er.slot = L("This time has already passed. Choose a later slot.", "यह समय निकल चुका है। बाद का स्लॉट चुनें।", "یہ وقت گزر چکا ہے۔ بعد کا سلاٹ چنیں۔");
      else if (st === "booked") er.slot = "This slot is full. Choose another.";
    }
    if (!f.consent) er.consent = "Please accept to continue.";
    const db = getDb(); const nowMs = Date.now();
    const recent = (db.rate || []).filter((x) => nowMs - x < 600000);
    if (!Object.keys(er).length && recent.length >= 5) er.form = "Too many bookings. Try again in 10 minutes.";
    if (!Object.keys(er).length && (db.meetings || []).filter((m) => m.date === f.date && m.slot === f.slot).length >= MT_CAP) er.slot = "This slot is full. Choose another.";
    setErr(er);
    if (Object.keys(er).length) { scrollErr(); return; }
    const m = { id: makeId("MTG"), acct: acctEmail(), purpose: f.purpose, name: f.name.trim(), mobile: f.mobile, email: f.email, date: f.date, slot: f.slot, bringLater: f.later, status: 2, at: nowMs };
    const finish = () => { db.meetings = (db.meetings || []).concat(m); db.rate = recent.concat(nowMs); if (!saveDb(db).ok) { toast(t("storageFull")); return; } setDone(m); };
    if (!REMOTE) { finish(); return; }
    setBusy(true);
    submitRemote("book_meeting", { p_id: m.id, p_purpose: m.purpose, p_name: m.name, p_mobile: m.mobile, p_email: m.email, p_date: m.date, p_slot: m.slot, p_bring_later: !!m.bringLater }).then((res) => {
      setBusy(false);
      if (!res.ok) { setErr({ form: res.error }); scrollErr(); return; }
      finish(); if (res.queued) toast(QUEUED_MSG);
    });
  };

  // ----- derived view data -----
  const monthDiff = (view.y - now.getFullYear()) * 12 + view.m - now.getMonth();
  const goMonth = (d) => {
    if ((d < 0 && monthDiff <= 0) || (d > 0 && monthDiff >= 3)) return false;
    setSlide(d);
    setView((v) => { const n = new Date(v.y, v.m + d, 1); return { y: n.getFullYear(), m: n.getMonth() }; });
    return true;
  };
  const swDown = (e) => { if (e.pointerType === "mouse" && e.button !== 0) return; sw.current = { x: e.clientX, y: e.clientY, on: true, moved: false, lock: "" }; };
  const swMove = (e) => {
    const c = sw.current; if (!c.on) return;
    let dx = e.clientX - c.x; const dy = e.clientY - c.y;
    if (!c.lock && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) c.lock = Math.abs(dx) > Math.abs(dy) ? "h" : "v";
    if (c.lock !== "h") return;
    c.moved = true;
    const want = (dx < 0 ? 1 : -1) * sgn;
    if ((want < 0 && monthDiff <= 0) || (want > 0 && monthDiff >= 3)) dx *= 0.25;
    setDrag(dx);
  };
  const swEnd = (e) => {
    const c = sw.current; if (!c.on) return;
    c.on = false;
    const dx = e.clientX - c.x;
    if (c.lock === "h" && Math.abs(dx) > 50) goMonth((dx < 0 ? 1 : -1) * sgn);
    setDrag(0);
  };
  const swCancel = () => { sw.current.on = false; setDrag(0); };
  const swClick = (e) => { if (sw.current.moved) { e.stopPropagation(); e.preventDefault(); sw.current.moved = false; } };
  const lead = new Date(view.y, view.m, 1).getDay();
  const dim = new Date(view.y, view.m + 1, 0).getDate();
  const wdNames = [0, 1, 2, 3, 4, 5, 6].map((i) => mtFmt(ymdLocal(new Date(2023, 0, 1 + i)), lang, { weekday: "short" }));
  const stText = { open: L("Open", "खुला", "کھلا"), fill: L("Filling fast", "जल्दी भर रहा", "جلد بھر رہا ہے"), few: L("Few left", "कम बचे", "کم باقی"), full: L("Full", "भरा हुआ", "بھرا ہوا"), off: L("Closed", "बंद", "بند") };
  const dayInfo = mtDay(f.date, booked, now);
  const slotsInfo = MT_SLOTS.map((s) => ({ ...s, ...mtSlotState(f.date, s, booked, now) }));
  const counts = [0, 1, 2].map((p) => slotsInfo.filter((s) => s.part === p && s.st === "free").length);
  const earliest = slotsInfo.find((s) => s.st === "free");
  const shown = slotsInfo.filter((s) => s.part === part);
  const slotObj = MT_SLOTS.find((s) => s.v === f.slot);
  const fmtSlot = (s) => s.h12 + ":" + s.mm + " " + s.ap;
  const dateLong = f.date ? mtFmt(f.date, lang, { weekday: "long", day: "numeric", month: "long" }) : "–";
  const stepsDone = [!!f.purpose, !!f.date && dayInfo.free > 0, !!f.slot, f.name.trim().length >= 2 && MOBILE_RE.test(f.mobile)].filter(Boolean).length;
  const purposeLabel = (() => { const p = PURPOSES.find((x) => x[0] === f.purpose); return p ? tr(p[1]) : "–"; })();
  const initials = BRAND[0].split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const qBtn = (label, ymd, key) => {
    const di = mtDay(ymd, booked, now);
    return <button key={key} type="button" className={"mt-q" + (f.date === ymd ? " on" : "")} disabled={di.state === "off" || di.state === "full"} onClick={() => pickDate(ymd, true)}>{label}</button>;
  };
  const tomorrow = ymdLocal(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));

  return (
    <div>
      <div id="pm-mscrim" className={"scrim fade" + (open ? " shown" : "")} onPointerDown={close} aria-hidden="true" />
      <div id="pm-meeting" className={"modal mtm" + (open ? " shown" : "")} aria-hidden={!open} ref={ref} role="dialog" aria-modal="true" aria-label={t("bookMeeting")}>
        <button type="button" className="burger" style={{ position: "absolute", top: 8, insetInlineEnd: 8, zIndex: 3 }} aria-label={t("close")} onClick={close}><Icon name="close" size={22} /></button>
        {done ? (
          <div>
            <div className="mt-ok" aria-hidden="true">✓</div>
            <h2 className="mt-title" style={{ textAlign: "center", paddingInlineEnd: 0 }}>{tr("Meeting booked")}</h2>
            <div className="mt-bk" style={{ marginTop: 14 }}>
              <div className="mt-bkh">
                <span className="mt-lg">{IMG.logo ? <img src={IMG.logo} alt="" /> : initials}</span>
                <div><b>{BRAND[li]}</b><span>{L("Your booking", "आपकी बुकिंग", "آپ کی بکنگ")}</span></div>
              </div>
              <div className="mt-bkg">
                <div><small>{tr("ID:").replace(":", "")}</small><b dir="ltr">{done.id}</b></div>
                <div><small>{L("Purpose", "उद्देश्य", "مقصد")}</small><b>{(() => { const p = PURPOSES.find((x) => x[0] === done.purpose); return p ? tr(p[1]) : "–"; })()}</b></div>
                <div><small>{tr("Date:").replace(":", "")}</small><b>{mtFmt(done.date, lang, { weekday: "short", day: "numeric", month: "short", year: "numeric" })}</b></div>
                <div><small>{tr("Time:").replace(":", "")}</small><b dir="ltr">{done.slot}</b></div>
                <div style={{ gridColumn: "1 / -1" }}><small>{tr("Office:").replace(":", "")}</small><b style={{ fontSize: 13.5, fontWeight: 600 }}>{pick(settings.address, lang)}</b></div>
              </div>
            </div>
            <div className="stack" style={{ marginTop: 14 }}>
              <a className="btn btn-wa" href={L(waLink(settings.whatsapp, waText("meeting", done, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{tr("Confirm on WhatsApp")}</a>
              <a className="btn btn-outline" href={L(settings.map)} target="_blank" rel="noopener noreferrer">{tr("Get Directions")} ↗</a>
              <a className="btn btn-outline" href={L("#/track")} onClick={close}>{tr("Track my request")}</a>
              <a className="btn btn-outline" href={L("#/")} onClick={close}>{tr("Back to home")}</a>
              <button type="button" className="btn btn-primary" onClick={close}>{t("close")}</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} noValidate dir={rtl ? "rtl" : "ltr"}>
            <h2 className="mt-title">{t("bookMeeting")}</h2>
            <p className="mt-sub">{L("Pick a day and time that suits you. It takes less than a minute.", "अपनी सुविधा का दिन और समय चुनें। एक मिनट से कम लगेगा।", "اپنی سہولت کا دن اور وقت چنیں۔ ایک منٹ سے کم لگے گا۔")}</p>
            <Err m={err.form} />

            <h3 className="mt-h"><span className="mt-n">1</span>{L("What is it about?", "किस बारे में?", "کس بارے میں؟")}</h3>
            <div className="mt-purp" role="radiogroup" aria-label={L("Purpose", "उद्देश्य", "مقصد")}>
              {PURPOSES.map(([v, l]) => (
                <button key={v} type="button" role="radio" aria-checked={f.purpose === v} className={"mt-pb" + (f.purpose === v ? " on" : "")} onClick={() => setF((s) => ({ ...s, purpose: v }))}>
                  <span aria-hidden="true" style={{ fontSize: 20 }}>{MT_PURPOSE_ICON[v]}</span><span>{tr(l)}</span>
                </button>
              ))}
            </div>

            <h3 className="mt-h"><span className="mt-n">2</span>{L("Pick a date", "तारीख़ चुनें", "تاریخ منتخب کریں")}</h3>
            <div className="mt-quick">
              {qBtn(L("Today", "आज", "آج"), today, "t")}
              {qBtn(L("Tomorrow", "कल", "کل"), tomorrow, "tm")}
              <button type="button" className="mt-q next" onClick={nextAvailable}>⚡ {L("Next available", "अगला उपलब्ध", "اگلا دستیاب")}</button>
            </div>
            <div className="mt-cal" dir={rtl ? "rtl" : "ltr"} onPointerDown={swDown} onPointerMove={swMove} onPointerUp={swEnd} onPointerCancel={swCancel} onClickCapture={swClick}>
              <div className="mt-mh">
                <button type="button" className="mt-nav" aria-label="Previous month" disabled={monthDiff <= 0} onClick={() => goMonth(-1)}>{rtl ? "›" : "‹"}</button>
                <b>{mtFmt(ymdLocal(new Date(view.y, view.m, 1)), lang, { month: "long", year: "numeric" })}</b>
                <button type="button" className="mt-nav" aria-label="Next month" disabled={monthDiff >= 3} onClick={() => goMonth(1)}>{rtl ? "‹" : "›"}</button>
              </div>
              <div key={view.y + "-" + view.m} className={"mt-slide" + (slide * sgn > 0 ? " sr" : slide * sgn < 0 ? " sl" : "")} style={{ transform: drag ? "translateX(" + drag + "px)" : undefined, transition: drag ? "none" : undefined }}>
              <div className="mt-wd">{wdNames.map((w, i) => <span key={i}>{w}</span>)}</div>
              <div className="mt-grid">
                {Array.from({ length: lead }).map((_, i) => <span key={"b" + i} />)}
                {Array.from({ length: dim }).map((_, i) => {
                  const ymd = view.y + "-" + pad2(view.m + 1) + "-" + pad2(i + 1);
                  const di = mtDay(ymd, booked, now);
                  const off = di.state === "off" || di.state === "full";
                  return (
                    <button key={ymd} type="button" disabled={off} aria-pressed={f.date === ymd}
                      aria-label={mtFmt(ymd, lang, { weekday: "long", day: "numeric", month: "long" }) + ", " + stText[di.state]}
                      className={"mt-day" + (f.date === ymd ? " sel" : "") + (ymd === today ? " today" : "") + (off ? " off" : "")}
                      onClick={() => pickDate(ymd, true)}>
                      <span>{i + 1}</span>{di.state !== "off" ? <i className={"mt-dot " + di.state} /> : null}
                    </button>
                  );
                })}
              </div>
              </div>
              <div className="mt-leg">
                <span><i className="mt-dot open" /> {stText.open}</span>
                <span><i className="mt-dot fill" /> {stText.fill}</span>
                <span><i className="mt-dot few" /> {stText.few}</span>
                <span><i className="mt-dot full" /> {stText.full}</span>
              </div>
            </div>
            <p className="mt-note">🕘 {HOURS[li]} · {L("Sunday closed", "रविवार बंद", "اتوار بند")}</p>
            <Err m={err.date} />

            <h3 className="mt-h" ref={timeRef}><span className="mt-n">3</span>{L("Pick a time", "समय चुनें", "وقت منتخب کریں")}</h3>
            <div className="mt-dc">
              <div className="mt-dch"><b>{dateLong}</b><span className={"mt-pill " + dayInfo.state}>{stText[dayInfo.state]}</span></div>
              <div className="mt-bar"><i style={{ width: (dayInfo.total ? Math.round((dayInfo.free / dayInfo.total) * 100) : 0) + "%" }} /></div>
              <small>{L(dayInfo.free + " free slots", dayInfo.free + " स्लॉट खाली", dayInfo.free + " سلاٹ خالی")}</small>
            </div>
            <div className="mt-tabs" role="tablist">
              {MT_PARTS.map((p, i) => (
                <button key={i} type="button" role="tab" aria-selected={part === i} className={"mt-tab" + (part === i ? " on" : "")} onClick={() => setPart(i)}>{p[li]} <b>{counts[i]}</b></button>
              ))}
            </div>
            {earliest ? <button type="button" className="mt-early" onClick={() => { setPart(earliest.part); setF((s) => ({ ...s, slot: earliest.v })); setErr((x) => ({ ...x, slot: undefined })); }}>⚡ {L("Earliest free slot:", "सबसे जल्दी खाली स्लॉट:", "سب سے پہلا خالی سلاٹ:")} <b dir="ltr">{fmtSlot(earliest)}</b></button> : null}
            <div className="mt-slots" dir={rtl ? "rtl" : "ltr"} role="listbox" aria-label={L("Time slots", "समय स्लॉट", "وقت کے سلاٹ")}>
              {shown.map((s) => {
                const dis = s.st !== "free";
                return (
                  <button key={s.v} type="button" role="option" aria-selected={f.slot === s.v} disabled={dis}
                    className={"mt-s" + (s.st === "booked" ? " booked" : s.st === "past" ? " booked past" : "") + (f.slot === s.v ? " sel" : "")}
                    onClick={() => { setF((x) => ({ ...x, slot: s.v })); setErr((x) => ({ ...x, slot: undefined })); }}>
                    <span className="tm" dir="ltr">{s.h12}:{s.mm}<small>{s.ap}</small></span>
                    {s.st === "booked" ? <span className="sb bk">{L("Booked", "बुक", "بک")}</span>
                      : s.st === "past" ? <span className="sb bk">{L("Passed", "बीत गया", "گزر گیا")}</span>
                      : s.left < MT_CAP ? <span className="sb">{L(s.left + " left", s.left + " बचा", s.left + " باقی")}</span>
                      : <i className="mt-dot open" />}
                  </button>
                );
              })}
            </div>
            <div className="mt-leg" style={{ justifyContent: "flex-start" }}>
              <span><i className="mt-sq" /> {L("Free", "खाली", "خالی")}</span>
              <span><i className="mt-sq bk" /> {L("Booked", "बुक", "بک")}</span>
              <span><i className="mt-sq sel" /> {L("Selected", "चुना हुआ", "منتخب")}</span>
            </div>
            <Err m={err.slot} />

            <div className="mt-bk">
              <div className="mt-bkh">
                <span className="mt-lg">{IMG.logo ? <img src={IMG.logo} alt="" /> : initials}</span>
                <div><b>{BRAND[li]}</b><span>{L("Your booking", "आपकी बुकिंग", "آپ کی بکنگ")}</span></div>
                <span className="mt-cnt">{stepsDone}/4</span>
              </div>
              <div className="mt-bkp"><i style={{ width: stepsDone * 25 + "%" }} /></div>
              <div className="mt-bkg">
                <div><small>{L("Purpose", "उद्देश्य", "مقصد")}</small><b>{purposeLabel}</b></div>
                <div><small>{tr("Date:").replace(":", "")}</small><b>{f.date ? mtFmt(f.date, lang, { weekday: "short", day: "numeric", month: "short" }) : "–"}</b></div>
                <div><small>{tr("Time:").replace(":", "")}</small><b dir="ltr">{slotObj ? fmtSlot(slotObj) : L("Not selected", "चुना नहीं", "منتخب نہیں")}</b></div>
                <div><small>{L("Name", "नाम", "نام")}</small><b>{f.name.trim() || "–"}</b></div>
              </div>
            </div>

            <h3 className="mt-h"><span className="mt-n">4</span>{L("Your details", "आपकी जानकारी", "آپ کی معلومات")}</h3>
            <Field id="mt-name" label={tr("Your name")} error={err.name}><input id="mt-name" placeholder={ex("name")} className="inp" autoComplete="name" dir={rtl ? "rtl" : undefined} style={rtl ? { textAlign: "right" } : undefined} value={f.name} onChange={up("name")} /></Field>
            <Field id="mt-mobile" hint={hint("mobile")} label={tr("Mobile number")} error={err.mobile}><input id="mt-mobile" placeholder={ex("mobile")} className="inp" dir="ltr" style={numInp} inputMode="numeric" autoComplete="tel" value={f.mobile} onChange={(e) => setF((s) => ({ ...s, mobile: cleanMobile(e.target.value) }))} /></Field>
            <Field id="mt-email" label={tr("Email (optional)")} error={err.email}><input id="mt-email" placeholder={ex("email")} className="inp" dir="ltr" style={numInp} type="email" value={f.email} onChange={up("email")} /></Field>
            <div className="card" style={{ padding: 16, marginTop: 14, boxShadow: "none", borderRadius: 18 }}>
              <b style={{ color: "var(--ink)" }}>{tr("Documents to bring")}</b>
              <ul style={{ margin: "8px 0", paddingInlineStart: 18, fontSize: 14 }}>{((settings.docLists && settings.docLists[f.purpose]) || DOCS[f.purpose]).map((d) => <li key={d}>{d}</li>)}</ul>
              <p style={{ fontSize: 12.5, margin: 0 }}>{DOC_NOTE}</p>
            </div>
            <label className="chk"><input id="mt-later" type="checkbox" checked={f.later} onChange={up("later")} /> {tr("I will bring some documents later")}</label>
            <label className="chk"><input id="mt-consent" type="checkbox" checked={f.consent} onChange={up("consent")} /> {tr("I agree to be contacted about this booking.")}</label>
            <Err m={err.consent} />
            <button type="submit" disabled={busy} className="btn btn-primary mt-submit">{busy ? "…" : t("bookMeeting") + " ›"}</button>
          </form>
        )}
      </div>
    </div>
  );
}

export const MeetingModal = React.memo(MeetingModalInner);
