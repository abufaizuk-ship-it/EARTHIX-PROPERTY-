"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L } from "@/lib/nav";
import { LANG_NOW, pick, tr, trEn } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { MOBILE_RE, UNITS, cleanMobile, fmtNum, fromSqft, toSqft } from "@/lib/helpers";
import { Err, Field, Icon, PageHead, SafeImg, prefersReducedMotion, useRevealOnce } from "@/components/common";
import { DOCS, DOC_NOTE, STAGES, ex, hint } from "@/lib/forms";
import { SearchSelect } from "@/components/forms";
import { GROUPS, LAND_RECORDS_URL, catName } from "@/lib/config";
import { EmiCard, PropertyCard } from "@/components/property";
import { allProps, getDb, getFounder, saveDb } from "@/lib/store";
import { QUEUED_MSG, REMOTE, rpc, submitRemote } from "@/lib/backend";
import { ensureTag } from "@/lib/dom";
import { CARDS, FAQS, LEGAL, STEPS, svc } from "@/lib/content";
import { IMG, LANG_IDX, brandSwap } from "@/lib/brand";
import { rvInitial } from "@/lib/seed";


export function ToolsPage({ settings }) {
  const { t } = useLang();
  const [val, setVal] = useState("1"), [unit, setUnit] = useState("Katha");
  const sq = toSqft(val, unit, settings.sqftPerKatha);
  return (
    <div className="wrap" style={{ paddingBottom: 48, maxWidth: 640 }}>
      <PageHead pill={t("pillTools")} plain="Small Tools, Big " hl="Clarity." sub={t("subTools")} />
      <form className="card" onSubmit={(e) => e.preventDefault()}>
        <h3 className="ct">{t("converter")}</h3>
        <label htmlFor="cv-val" className="lbl">{t("value")}</label><input id="cv-val" placeholder={ex("area")} className="inp" dir="ltr" inputMode="decimal" value={val} onChange={(e) => setVal(e.target.value)} />
        <SearchSelect id="cv-unit" label={t("unit")} value={unit} options={UNITS} onChange={setUnit} />
        <table style={{ width: "100%", marginTop: 14 }}><tbody>{UNITS.map((u) => <tr key={u}><td>{u}</td><td dir="ltr" style={{ textAlign: "end" }}>{fmtNum(fromSqft(sq, u, settings.sqftPerKatha), 3)}</td></tr>)}</tbody></table>
        <p className="cb" style={{ fontSize: 13 }}>{t("unitNote")}</p>
        <a className="btn btn-outline" href={L(LAND_RECORDS_URL)} target="_blank" rel="noopener noreferrer">{tr("Bihar Bhumi ↗")}</a>
      </form>
      <EmiCard />
    </div>
  );
}


export function TrackPage() {
  const [id, setId] = useState(""), [mobile, setMobile] = useState(""), [res, setRes] = useState(null), [msg, setMsg] = useState("");
  const find = (e) => {
    e.preventDefault();
    const db = getDb(); const key = id.trim().toUpperCase();
    const hit = (db.requests || []).concat(db.meetings || []).find((r) => r.id.toUpperCase() === key && r.mobile === mobile);
    const local = () => { setRes(hit || null); setMsg(hit ? "" : "No request found for this ID and mobile number."); };
    if (!REMOTE) { local(); return; }
    setMsg("Checking…"); setRes(null);
    rpc("track_item", { p_id: key, p_mobile: mobile }).then((r) => { if (r) { setRes({ status: r.status }); setMsg(""); } else { setRes(null); setMsg("No request found for this ID and mobile number."); } }).catch(() => { local(); if (!hit) setMsg("Could not check right now. Please try again."); });
  };
  return (
    <div className="wrap" style={{ maxWidth: 560, paddingBottom: 48 }}>
      <PageHead pill="Track" plain="Track my " hl="request." sub="Enter your request ID and mobile number." />
      <form className="card" onSubmit={find} noValidate>
        <Field id="tr-id" hint={hint("reqid")} label={tr("Request or meeting ID")}><input id="tr-id" placeholder={ex("reqid")} className="inp" dir="ltr" value={id} onChange={(e) => setId(e.target.value)} /></Field>
        <Field id="tr-mobile" hint={hint("mobile")} label={tr("Mobile number")}><input id="tr-mobile" placeholder={ex("mobile")} className="inp" dir="ltr" inputMode="numeric" value={mobile} onChange={(e) => setMobile(cleanMobile(e.target.value))} /></Field>
        <Err m={msg} />
        <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{tr("Track")}</button>
        {res && <ol className="tl">{STAGES.map((s, k) => <li key={s} className={k <= (res.status || 0) ? "on" : ""}>{tr(s)}</li>)}</ol>}
      </form>
    </div>
  );
}

export function FaqPage() {
  useEffect(() => {
    const el = ensureTag("script", "pm-faq", { type: "application/ld+json" });
    el.textContent = JSON.stringify({ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: FAQS.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) });
    return () => { const x = document.getElementById("pm-faq"); if (x) x.remove(); };
  }, []);
  return (
    <div className="wrap" style={{ maxWidth: 680, paddingBottom: 48 }}>
      <PageHead pill="FAQ" plain="Questions, " hl="answered." />
      {FAQS.map(([q, a], k) => <details className="card acc" key={k}><summary>{tr(q)}</summary><p className="cb">{q === "Which areas do you serve?" ? svc("note") + " " + [" Right now: the 10 blocks of Saharsa plus Saharsa Town.", " अभी: सहरसा के 10 ब्लॉक और सहरसा टाउन।", " اس وقت: سہرسا کے 10 بلاک اور سہرسا ٹاؤن۔"][LANG_IDX[LANG_NOW.v] ?? 0] : tr(a)}</p></details>)}
    </div>
  );
}

export function LegalPage({ route }) {
  const tab = LEGAL[route.params.tab] ? route.params.tab : "privacy";
  return (
    <div className="wrap" style={{ maxWidth: 680, paddingBottom: 48 }}>
      <PageHead pill="Legal" plain={LEGAL[tab][0] + " "} hl="notice." />
      <div className="chiprow" style={{ marginBottom: 16 }}>{Object.keys(LEGAL).map((k) => <a key={k} className="areachip" aria-current={k === tab} style={k === tab ? { background: "var(--teal-soft)" } : null} href={L("#/legal?tab=" + k)}>{tr(LEGAL[k][0])}</a>)}</div>
      <div className="card"><p className="cb">{tr(LEGAL[tab][1])}</p>{tab === "disclaimer" && <a href={L(LAND_RECORDS_URL)} target="_blank" rel="noopener noreferrer" style={{ color: "var(--teal)", fontWeight: 600 }}>{tr("Bihar Bhumi ↗")}</a>}</div>
    </div>
  );
}

// Types the message letter by letter (like handwriting). The invisible full text keeps the height fixed, so nothing jumps.
export function TypeText({ text, active, start, ms }) {
  const liveRef = useRef(null);
  useEffect(() => {
    const el = liveRef.current;
    if (!el) return undefined;
    if (!active) { el.textContent = ""; el.classList.remove("typing"); return undefined; }
    if (prefersReducedMotion()) { el.textContent = text; return undefined; }
    const chars = typeof Intl !== "undefined" && Intl.Segmenter ? Array.from(new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(text), (x) => x.segment) : Array.from(text);
    let raf = 0, t0 = 0, last = -1;
    const tick = (now) => {
      if (!t0) t0 = now;
      const k = Math.max(0, Math.min(chars.length, Math.floor((now - t0 - start * 1000) / ms)));
      if (k !== last) { last = k; el.textContent = chars.slice(0, k).join(""); }
      el.classList.toggle("typing", k < chars.length);
      if (k < chars.length) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [text, active, start, ms]);
  return <span className="tq"><span className="tq-ghost" aria-hidden="true">{text}</span><span className="tq-live" ref={liveRef} aria-hidden="true" /></span>;
}

export function FounderCard({ settings }) {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const F = getFounder(settings);
  const L = (en, hi, ur) => [en, hi, ur][i];
  const [ref, on] = useRevealOnce(0.3);
  const text = String(brandSwap(F.note[i], i) || "").trim();
  const n = Array.from(text).length;
  const START = 1.3;
  const ms = Math.max(14, Math.min(45, 5200 / Math.max(1, n)));
  const sd = (START + (n * ms) / 1000 + 0.3).toFixed(2) + "s";
  return (
    <section ref={ref} className={"fnd" + (on ? " in" : "")} aria-label={L("Message from the Founder", "संस्थापक का संदेश", "بانی کا پیغام")}>
      <div className="fnd-ph">
        {F.photo ? <img src={F.photo} alt={F.name[i]} loading="lazy" /> : <div className="fnd-ini" aria-hidden="true">{rvInitial(F.name[0])}</div>}
        
      </div>
      <div className="fnd-tx">
        <span className="pill">{L("Message from the Founder", "संस्थापक का संदेश", "بانی کا پیغام")}</span>
        <blockquote aria-label={text}><TypeText text={text} active={on} start={START} ms={ms} /></blockquote>
        <div className="fnd-sig" style={{ "--sd": sd }}><b>{F.name[i]}</b><span>{brandSwap(F.role[i], i)}</span></div>
      </div>
    </section>
  );
}

export function AboutPage({ settings }) {
  const { lang } = useLang();
  return (
    <div className="wrap" style={{ maxWidth: 680, paddingBottom: 48 }}>
      <PageHead pill="About" plain="Private, local, " hl="honest." sub="Earthix Property connects verified buyers and sellers in Saharsa district without ever publishing their details." />
      <FounderCard settings={settings} />
    </div>
  );
}

export function FraudTips() {
  const tips = ["Never pay advance money to see a property.", "Meet only at our office with papers in front of you.", "Check land records on the Bihar Bhumi portal.", "Never hand original documents to anyone."];
  return (
    <div className="card" style={{ marginTop: 16 }}>
      <h3 className="ct" style={{ marginTop: 0 }}>{tr("Fraud-safety tips")}</h3>
      {tips.map((x) => <div key={x} className="bul"><span style={{ color: "var(--green)" }}><Icon name="check" size={18} /></span>{tr(x)}</div>)}
      <a href={L("#/legal?tab=disclaimer")} style={{ color: "var(--teal)", fontWeight: 600, display: "inline-block", marginTop: 12 }}>{tr("Read the Disclaimer ›")}</a>
    </div>
  );
}

export function HowPage({ route }) {
  const { lang } = useLang();
  const startAt = Math.min(Math.max(Number(route && route.params.step) || 0, 0), 4);
  const docsFor = (k) => (k === 1 ? DOCS.buy.concat(DOCS.sell) : k === 0 ? ["Nothing to upload. Bring papers to the meeting."] : k === 2 ? ["Identity proof of both sides, checked by us."] : ["Sale deed, khatiyan, mutation paper, rent receipt and ID proofs."]);
  return (
    <div className="wrap" style={{ paddingBottom: 48, maxWidth: 720 }}>
      <PageHead pill="How it works" plain="Four simple " hl="steps." sub="No public listings. No pressure." />
      {CARDS.how.map(([ic, title, body], k) => (
        <details className="card acc" key={title} open={startAt === k + 1}>
          <summary><span className="tile" style={{ marginInlineEnd: 12 }}><Icon name={ic} size={22} /></span>{k + 1}. {trEn(title, lang)}</summary>
          <p className="cb"><b>{tr("What happens:")}</b> {tr(STEPS[k][0])}</p>
          <p className="cb"><b>{tr("What you need:")}</b> {tr(STEPS[k][1])}</p>
          <details><summary style={{ fontWeight: 600, cursor: "pointer", minHeight: 44, display: "flex", alignItems: "center" }}>{tr("Documents")}</summary><ul style={{ paddingInlineStart: 18, fontSize: 14 }}>{docsFor(k).map((d) => <li key={d}>{tr(d)}</li>)}</ul><p style={{ fontSize: 12.5 }}>{tr(DOC_NOTE)}</p></details>
        </details>
      ))}
      <p style={{ textAlign: "center", marginTop: 24 }}><a className="btn btn-primary" href={L("#/sell")}>{tr("Start with a Sell request ›")}</a></p>
    </div>
  );
}

export function CategoriesPage() {
  const { lang } = useLang();
  return (
    <div className="wrap" style={{ paddingBottom: 48 }}>
      <PageHead pill="Categories" plain="Our " hl="categories." />
      {Object.keys(GROUPS).map((g) => <div key={g}><h3 className="ct" style={{ textTransform: "capitalize" }}>{g}</h3><div className="tiles">{GROUPS[g].map((s) => <a key={s} className="ctile" href={L("#/buy/" + s)}><div className="im"><SafeImg src={((getDb().settings.catImages || {})[s]) || IMG.categories[s]} category={s} alt={catName(s, lang)} width={600} height={450} /></div><span>{catName(s, lang)}</span></a>)}</div></div>)}
    </div>
  );
}

export function SavedPage({ saved, toggle }) {
  const { t } = useLang();
  const list = allProps().filter((p) => saved.includes(p.id));
  return (
    <div className="wrap" style={{ paddingBottom: 48 }}>
      <PageHead pill={t("saved")} plain="Saved " hl="properties." />
      {list.length ? <div className="grid pgrid">{list.map((p) => <PropertyCard key={p.id} p={p} saved onToggleSave={toggle} />)}</div> : <div className="card" style={{ textAlign: "center" }}><p>{tr("Nothing saved yet.")}</p><a className="btn btn-primary" href={L("#/buy")}>{t("browse")}</a></div>}
    </div>
  );
}

export function ContactPage({ settings, toast }) {
  const { t } = useLang();
  const [f, setF] = useState({ name: "", mobile: "", message: "" }), [err, setErr] = useState({});
  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (f.name.trim().length < 2) er.name = "Enter your name.";
    if (!MOBILE_RE.test(f.mobile)) er.mobile = "Enter a valid 10-digit mobile number.";
    if (f.message.trim().length < 5) er.message = "Write a short message.";
    setErr(er); if (Object.keys(er).length) return;
    const finish = () => {
      if (!REMOTE) { const db = getDb(); db.messages = (db.messages || []).concat({ ...f, at: Date.now() }); if (!saveDb(db).ok) { toast(t("storageFull")); return; } }
      toast("Message sent"); setF({ name: "", mobile: "", message: "" });
    };
    if (!REMOTE) { finish(); return; }
    submitRemote("send_message", { p_name: f.name.trim(), p_mobile: f.mobile, p_message: f.message.trim() }).then((res) => { if (!res.ok) { toast(res.error); return; } finish(); if (res.queued) toast(QUEUED_MSG); });
  };
  const copy = (n) => { try { navigator.clipboard.writeText(n).then(() => toast("Number copied"), () => toast(n)); } catch (e) { toast(n); } };
  return (
    <div className="wrap" style={{ maxWidth: 640, paddingBottom: 48 }}>
      <PageHead pill={t("navContact")} plain="Talk to " hl="us." />
      <div className="card" style={{ marginBottom: 16 }}>
        {settings.phones.map((n) => <div key={n} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", minHeight: 44 }}><a href={L("tel:+91" + n)} dir="ltr">{n}</a><button type="button" className="btn btn-outline" style={{ height: 36 }} onClick={() => copy(n)}>{tr("Copy")}</button></div>)}
        <p className="cb">{pick(settings.address, useLang().lang)}</p>
        <a href={L(settings.map)} target="_blank" rel="noopener noreferrer" style={{ color: "var(--teal)", fontWeight: 600 }}>{tr("Get Directions")} ↗</a>
      </div>
      <form className="card" onSubmit={submit} noValidate>
        <Field id="c-name" label={tr("Your name")} error={err.name}><input id="c-name" placeholder={ex("name")} className="inp" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field id="c-mobile" hint={hint("mobile")} label={tr("Mobile number")} error={err.mobile}><input id="c-mobile" placeholder={ex("mobile")} className="inp" dir="ltr" inputMode="numeric" value={f.mobile} onChange={(e) => setF({ ...f, mobile: cleanMobile(e.target.value) })} /></Field>
        <Field id="c-msg" hint={hint("msg")} label={tr("Message")} error={err.message}><textarea id="c-msg" placeholder={ex("msg")} className="inp" style={{ height: 100, padding: 12 }} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></Field>
        <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{tr("Send message")}</button>
      </form>
    </div>
  );
}
