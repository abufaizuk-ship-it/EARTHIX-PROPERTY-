"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { pick, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { INFO, waText } from "@/lib/content";
import { openMeeting } from "@/lib/dom";
import { catName, waLink } from "@/lib/config";
import { navigate, L } from "@/lib/nav";
import { allProps } from "@/lib/store";
import { DOCS, DOC_NOTE } from "@/lib/forms";
import { Icon } from "@/components/common";
import { fmtINR } from "@/lib/helpers";
import { priceSuffix } from "@/lib/seed";


export function InfoHost({ settings }) {
  const { lang } = useLang();
  const li = lang === "hi" ? 1 : 0;
  const [key, setKey] = useState(null);
  useEffect(() => { const on = (e) => setKey(e.detail); window.addEventListener("pm-info", on); return () => window.removeEventListener("pm-info", on); }, []);
  useEffect(() => {
    if (!key) return undefined;
    const esc = (e) => { if (e.key === "Escape") setKey(null); };
    document.addEventListener("keydown", esc);
    const prev = document.body.style.overflow; document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", esc); document.body.style.overflow = prev; };
  }, [key]);
  const info = key ? INFO[key] : null;
  if (!info) return null;
  const close = () => setKey(null);
  const go = (href) => {
    close();
    if (href === "book") { openMeeting("consult"); return; }
    if (href === "wa") { window.open(waLink(settings.whatsapp, waText("general", {}, lang)), "_blank", "noopener"); return; }
    if (href === "#areas") { const el = document.getElementById("sec-areas"); if (el) el.scrollIntoView({ behavior: "smooth", block: "center" }); return; }
    navigate(href);
  };
  const verified = info.verified ? allProps().filter((p) => p.verified).slice(0, 5) : [];
  const docs = info.docs ? (DOCS[info.docs] || []) : [];
  return (
    <div>
      <div className="sheet-bg" onClick={close} />
      <div className="sheet infosheet" role="dialog" aria-modal="true" aria-label={info.t[li]}>
        <div className="sheet-head"><span className="infohead"><span className="tile"><Icon name={info.ic} size={22} /></span><b>{info.t[li]}</b></span><button type="button" className="burger" style={{ width: 40, height: 40 }} aria-label={tr("Close")} onClick={close}><Icon name="close" size={18} /></button></div>
        <div className="sheet-list infobody">
          <p className="infolead">{info.lead[li]}</p>
          {info.pts.length > 0 && <ul className="infopts">{info.pts.map((p) => <li key={p[0]}><span><Icon name="check" size={16} /></span>{p[li]}</li>)}</ul>}
          {docs.length > 0 && <div className="infobox"><h4>{info.docsBuy ? (li ? "बेचने के लिए कागज़ात" : "Papers to bring when selling") : (li ? "कागज़ात जो जाँचे जाते हैं" : "Papers we check")}</h4><ul className="infopts">{docs.map((d) => <li key={d}><span><Icon name="check" size={16} /></span>{d}</li>)}</ul>{info.docsBuy && <h4 style={{ marginTop: 14 }}>{li ? "खरीदने के लिए कागज़ात" : "Papers to bring when buying"}</h4>}{info.docsBuy && <ul className="infopts">{DOCS.buy.map((d) => <li key={d}><span><Icon name="check" size={16} /></span>{d}</li>)}</ul>}<p className="hint">{DOC_NOTE}</p></div>}
          {info.verified && <div className="infobox"><h4>{li ? "अभी की Verified लिस्टिंग" : "Verified listings right now"}</h4>{verified.length === 0 ? <p className="hint">{li ? "अभी कोई verified लिस्टिंग नहीं है। जल्द ही जुड़ेंगी।" : "No verified listing is live at the moment. New ones are added after admin checks."}</p> : verified.map((p) => <a key={p.id} className="infolist" href={L("#/property/" + p.id)} onClick={close}><b>{pick(p.title, lang)}</b><span>{catName(p.category, lang)} · {p.block} · {fmtINR(p.price)}{priceSuffix(p) ? (li ? " / माह" : " / month") : ""}</span></a>)}</div>}
          {info.contact && <div className="infobox"><h4>{li ? "हमारा ऑफ़िस" : "Our office"}</h4><p className="hint" style={{ color: "var(--body)" }}>{pick(settings.address, lang)}<br />{pick(settings.hours, lang)}</p><div className="stack"><a className="btn btn-outline" href={L("tel:" + String((settings.phones || [""])[0]).replace(/[^\d+]/g, ""))}>{li ? "कॉल करें" : "Call us"}</a><a className="btn btn-outline" href={L(settings.map)} target="_blank" rel="noopener noreferrer">{li ? "रास्ता देखें" : "Get directions"}</a></div></div>}
        </div>
        <div className="infocta">{info.cta.map(([en, hi, href], k) => <button key={en} type="button" className={"btn " + (k === 0 ? "btn-primary" : "btn-outline")} onClick={() => go(href)}>{li ? hi : en}</button>)}</div>
      </div>
    </div>
  );
}
