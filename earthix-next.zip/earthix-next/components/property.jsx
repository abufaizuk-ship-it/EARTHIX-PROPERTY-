"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L3, LANG_NOW, pick, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { hasExactMap, isDirectVideo, mapDirections, mapLink, propImages, propVideos, resizeUrl, sceneDataUrl, sceneKey, sceneUrl, slideLabel, ytId } from "@/lib/media";
import { Field, Icon, NotFound, PageHead, SafeImg, Section, SpecList, WhatsAppIcon, useFocusTrap, useSwipe } from "@/components/common";
import { BLOCKS_FILTER, CATEGORIES, EMI_CATEGORIES, GROUPS, WEB, catName, waLink } from "@/lib/config";
import { openEnquiry, openMeeting, openViewer } from "@/lib/dom";
import { IMG_ILLUSTRATIVE, LANG_IDX } from "@/lib/brand";
import { priceSuffix, propSpecs } from "@/lib/seed";
import { allProps, getDb } from "@/lib/store";
import { UNITS, fmtINR, pricePerKatha, toSqft } from "@/lib/helpers";
import { waText } from "@/lib/content";
import { BUY_LAST, ex } from "@/lib/forms";
import { navigate, replaceQuery, L } from "@/lib/nav";
import { BuyCta, SearchSelect } from "@/components/forms";


// Video clip made from the property views (slow pan + zoom). Real videos from IMG.videos / admin play instead when present.
export function AutoClip({ p, title, onClose, onExpand }) {
  const { lang } = useLang();
  const slides = propImages(p);
  const n = slides.length;
  const [k, setK] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (paused || n < 2) return undefined;
    const id = setTimeout(() => setK((v) => (v + 1) % n), 2600);
    return () => clearTimeout(id);
  }, [k, paused, n]);
  const label = slideLabel(slides[k], k, lang);
  const eat = (fn) => (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
  return (
    <div className={"aclip" + (paused ? " paused" : "") + (onExpand ? " expandable" : "")} onClick={onExpand} role="group" aria-label={L3(lang, "Video preview", "वीडियो झलक", "ویڈیو جھلک")}>
      <div className="aclip-bar" key={"b" + k}><i /></div>
      <div className={"aclip-s" + (k % 2 ? " alt" : "")} key={"s" + k}><SafeImg src={slides[k]} category={p.category} alt={title + " – " + label} width={800} height={600} eager /></div>
      <span className="aclip-cap">{"▶ " + (k + 1) + "/" + n + " · " + label}</span>
      <div className="aclip-ctl">
        <button type="button" aria-label={paused ? "Play" : "Pause"} onClick={eat(() => setPaused((v) => !v))}>{paused ? "▶" : "❚❚"}</button>
        {onExpand && <button type="button" aria-label="Full screen" onClick={eat(onExpand)}>⛶</button>}
        {onClose && <button type="button" aria-label="Close video" onClick={eat(onClose)}>✕</button>}
      </div>
    </div>
  );
}

export function MediaViewerHost() {
  const { lang } = useLang();
  const [v, setV] = useState(null);
  const [i, setI] = useState(0);
  const [zoom, setZoom] = useState(false);
  const ref = useRef(null);
  const n = v && v.images ? v.images.length : 0;
  const close = useCallback(() => { try { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen(); } catch (e) { /* closing anyway */ } setV(null); setZoom(false); }, []);
  const go = useCallback((d) => { setZoom(false); setI((x) => (n ? (x + d + n) % n : 0)); }, [n]);
  const sw = useSwipe(() => { if (!zoom) go(1); }, () => { if (!zoom) go(-1); });
  useEffect(() => {
    const on = (e) => { setV(e.detail || null); setI((e.detail && e.detail.index) || 0); setZoom(false); };
    window.addEventListener("pm-viewer", on);
    return () => window.removeEventListener("pm-viewer", on);
  }, []);
  useFocusTrap(!!v, ref, close);
  useEffect(() => {
    if (!v) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    try { const el = ref.current; if (el && el.requestFullscreen) { const r = el.requestFullscreen(); if (r && r.catch) r.catch(() => {}); } } catch (e) { /* the overlay already covers the screen */ }
    const onFs = () => { if (!document.fullscreenElement) setV(null); };
    const onKey = (e) => { if (e.key === "ArrowRight") go(LANG_NOW.v === "ur" ? -1 : 1); else if (e.key === "ArrowLeft") go(LANG_NOW.v === "ur" ? 1 : -1); };
    document.addEventListener("fullscreenchange", onFs);
    document.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = prevOverflow; document.removeEventListener("fullscreenchange", onFs); document.removeEventListener("keydown", onKey); };
  }, [v, go]);
  if (!v) return null;
  const cat = CATEGORIES.some((c) => c.slug === v.category) ? v.category : "farmland";
  const title = v.title || v.alt || "";
  let body = null;
  if (v.clip && v.p) body = <div className="mv-clip"><AutoClip p={v.p} title={title} /></div>;
  else if (v.video) {
    body = ytId(v.video)
      ? <iframe className="mv-video" title={title} src={"https://www.youtube-nocookie.com/embed/" + ytId(v.video) + "?autoplay=1&rel=0"} allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen />
      : <video className="mv-video" controls autoPlay playsInline src={v.video} />;
  } else if (n) {
    const src = v.images[i];
    const sv = sceneKey(src);
    const url = sv !== null || !src ? sceneUrl(cat, sv === null ? 0 : sv) : resizeUrl(src, 1600);
    body = (
      <div className={"mv-stage" + (zoom ? " zoom" : "")} onTouchStart={zoom ? undefined : sw.onTouchStart} onTouchEnd={zoom ? undefined : sw.onTouchEnd}>
        <img key={i} className="mv-img" src={url} alt={(v.alt || "") + " " + slideLabel(src, i, lang)} referrerPolicy="no-referrer" draggable={false} onClick={() => setZoom((z) => !z)} onError={(e) => { const d = sceneDataUrl(cat, sv === null ? 0 : sv); if (e.currentTarget.src !== d) e.currentTarget.src = d; }} />
      </div>
    );
  }
  return (
    <div className="mv" ref={ref} role="dialog" aria-modal="true" aria-label={title || "Media viewer"}>
      <div className="mv-top">
        <span className="mv-count">{n > 1 && !v.video && !v.clip ? (i + 1) + " / " + n : ""}</span>
        <span className="mv-title">{title}</span>
        <button type="button" className="mv-x" aria-label="Close" onClick={close}>✕</button>
      </div>
      {body}
      {n > 1 && !v.video && !v.clip && <button type="button" className="mv-arr l" aria-label="Previous" onClick={() => go(-1)}>‹</button>}
      {n > 1 && !v.video && !v.clip && <button type="button" className="mv-arr r" aria-label="Next" onClick={() => go(1)}>›</button>}
      {n > 0 && !v.video && !v.clip && <div className="mv-hint">{zoom ? L3(lang, "Tap to zoom out", "छोटा करने के लिए टैप करें", "چھوٹا کرنے کے لیے ٹیپ کریں") : L3(lang, "Tap photo to zoom", "बड़ा करने के लिए फ़ोटो टैप करें", "بڑا کرنے کے لیے تصویر ٹیپ کریں")}</div>}
    </div>
  );
}

export function CardMedia({ p, title }) {
  const { lang, t } = useLang();
  const imgs = propImages(p), vids = propVideos(p);
  const n = imgs.length;
  const [gi, setGi] = useState(0);
  const go = useCallback((d) => setGi((v) => (v + d + n) % n), [n]);
  const sw = useSwipe(() => go(1), () => go(-1));
  const rtl = LANG_NOW.v === "ur";
  const eat = (fn) => (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
  const vu = vids[0] || "";
  const openPhoto = () => openViewer({ images: imgs, index: gi, alt: title, title, category: p.category });
  const playVideo = () => { if (!ytId(vu) && !isDirectVideo(vu)) { window.open(vu, "_blank", "noopener,noreferrer"); return; } openViewer({ video: vu, title }); };
  return (
    <div className="im pc-media" onTouchStart={sw.onTouchStart} onTouchEnd={sw.onTouchEnd}>
      <div className="pc-link" role="button" tabIndex={0} aria-label={title + " – " + L3(lang, "open full screen", "फ़ुल स्क्रीन में खोलें", "فل اسکرین میں کھولیں")} onClick={openPhoto} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPhoto(); } }} style={{ cursor: "zoom-in" }}>
        <div className="pc-track" style={{ transform: "translateX(" + (rtl ? gi : -gi) * 100 + "%)" }}>
          {imgs.map((src, k) => <div className="pc-slide" key={k}>{Math.abs(k - gi) <= 1 ? <SafeImg src={src} category={p.category} alt={title + " – " + slideLabel(src, k, lang)} width={640} height={480} /> : null}</div>)}
        </div>
      </div>
      <span className="tag" style={{ top: 10, insetInlineStart: 10 }}>{t("showcaseTag")}</span>
      {IMG_ILLUSTRATIVE && <span className="tag" style={{ top: 36, insetInlineStart: 10 }}>{t("illustrative")}</span>}
      {n > 1 && <button type="button" className="pc-arr l" aria-label={t("prev")} onClick={eat(() => go(-1))}>‹</button>}
      {n > 1 && <button type="button" className="pc-arr r" aria-label={t("next")} onClick={eat(() => go(1))}>›</button>}
      <button type="button" className="pc-vbtn" onClick={eat(vids.length ? playVideo : () => openViewer({ clip: true, p, title }))}>{"▶ " + (vids.length ? L3(lang, "Watch video", "वीडियो देखें", "ویڈیو دیکھیں") : L3(lang, "Video tour", "वीडियो टूर", "ویڈیو ٹور"))}</button>
      <span className="pc-count">{"📷 " + (gi + 1) + "/" + n}</span>
    </div>
  );
}

export function PropertyCardInner({ p, saved, onToggleSave }) {
  const { lang, t } = useLang();
  const title = pick(p.title, lang);
  const sp = useMemo(() => propSpecs(p, lang, getDb().settings), [p, lang]);
  return (
    <article className="pcard">
      <CardMedia p={p} title={title} />
      <button type="button" className="heart" aria-label={t("save")} aria-pressed={!!saved} onClick={() => onToggleSave && onToggleSave(p.id)}><Icon name="heart" size={18} /></button>
      <div className="pbody">
        <div className="price">{fmtINR(p.price)}{priceSuffix(p) ? t("perMonth") : ""}</div>
        <a className="ptitle-a" href={L("#/property/" + p.id)}><div className="ptitle">{title}</div></a>
        <div className="loc"><Icon name="pin" size={14} />{p.locality}, {p.block}</div>
        {sp.hl.length > 0 && <div className="pc-chips">{sp.hl.slice(0, 5).map((h, i) => <span key={i}>{h}</span>)}</div>}
        {sp.desc ? <p className="pc-desc">{sp.desc}</p> : null}
        {sp.quick.length > 0 && <div className="pc-quick">{sp.quick.map(([k, v], i) => <div key={i}><small>{k}</small><b>{v}</b></div>)}</div>}
        <a className="pc-more" href={L("#/property/" + p.id)}>{L3(lang, "Full details", "पूरा विवरण", "مکمل تفصیل")} ›</a>
        <PropActions p={p} />
        <div className="pc-foot">
          <a className="maplink" href={L(mapLink(p))} target="_blank" rel="noopener noreferrer" aria-label={"Map: " + title}>{"📍 " + (hasExactMap(p) ? "Exact location" : "View on map") + " ›"}</a>
          <span className="mini">{catName(p.category, lang)}</span>
          {p.verified && <span className="mini v"><Icon name="shield" size={12} />{t("verified")}</span>}
        </div>
      </div>
    </article>
  );
}

// WhatsApp + Book a Meeting, on the card itself (not a bar across the page)
export function PropActions({ p, children }) {
  const { lang, t } = useLang();
  const st = getDb().settings;
  const ppk = UNITS.includes(p.unit) ? pricePerKatha(p.price, p.area, p.unit, st.sqftPerKatha) : null;
  const msg = waText("property", { p, link: "https://" + WEB + "/" + lang + "/property/" + p.id, ppk }, lang);
  return (
    <div className="pc-act">
      <a className="btn btn-wa" href={L(waLink(st.whatsapp, msg))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{tr("WhatsApp")}</a>
      <button type="button" className="btn btn-primary" onClick={() => openMeeting("buy")}>{t("bookMeeting")}</button>
      <button type="button" className="btn btn-req" onClick={() => openEnquiry(p)}>{"✉ " + tr("Send Request")}</button>
      {children}
    </div>
  );
}

// Detail page: one card with every fact
export function PropDetailsCard({ p, settings, head, foot }) {
  const { lang } = useLang();
  const sp = useMemo(() => propSpecs(p, lang, settings), [p, lang, settings]);
  return (
    <div className="card pdet">
      {head}
      <h3 className="ct pdhead">{L3(lang, "Full property details", "प्रॉपर्टी का पूरा विवरण", "پراپرٹی کی مکمل تفصیل")}</h3>
      {sp.hl.length > 0 && <div className="pc-chips lg">{sp.hl.map((h, i) => <span key={i}>{h}</span>)}</div>}
      <SpecList rows={sp.rows} />
      {sp.near.length > 0 && <><h4 className="pdh">{L3(lang, "Nearby", "आस-पास", "آس پاس")}</h4><ul className="pdl">{sp.near.map((x, i) => <li key={i}>{x}</li>)}</ul></>}
      <h4 className="pdh">{L3(lang, "Documents to check before you pay", "पैसे देने से पहले ये काग़ज़ जाँचें", "ادائیگی سے پہلے یہ کاغذات جانچیں")}</h4>
      <ul className="pdl ck">{sp.docs.map((x, i) => <li key={i}>{x}</li>)}</ul>
      {foot}
      <p className="pdnote">{L3(lang, "Showcase listing: figures are for illustration. Local units vary; confirm with the amin or registry office.", "नमूना लिस्टिंग: आँकड़े उदाहरण के लिए हैं। स्थानीय इकाइयाँ अलग होती हैं; अमीन या रजिस्ट्री कार्यालय से पुष्टि करें।", "نمونہ لسٹنگ: اعداد مثال کے لیے ہیں۔ مقامی اکائیاں مختلف ہوتی ہیں؛ امین یا رجسٹری دفتر سے تصدیق کریں۔")}</p>
    </div>
  );
}

export function Thumbs({ list, cur, onPick, category, title }) {
  if (list.length < 2) return null;
  return <div className="thumbs" role="tablist" aria-label="Photos">{list.map((src, k) => <button key={k} type="button" role="tab" aria-selected={k === cur} className={k === cur ? "on" : ""} onClick={() => onPick(k)} aria-label={"Photo " + (k + 1)}><SafeImg src={src} category={category} alt={title + " thumbnail " + (k + 1)} width={160} height={120} /></button>)}</div>;
}

export function MediaClips({ p, title }) {
  const { lang } = useLang();
  const vids = propVideos(p);
  if (!vids.length) {
    return (
      <div className="card clips">
        <h3 className="ct" style={{ marginTop: 0 }}>{L3(lang, "Video tour (preview clip)", "वीडियो टूर (झलक क्लिप)", "ویڈیو ٹور (جھلک کلپ)")}</h3>
        <div className="aclip-wrap"><AutoClip p={p} title={title} onExpand={() => openViewer({ clip: true, p, title })} /></div>
        <p className="hint" style={{ fontWeight: 700 }}>{L3(lang, "This clip is made from the property views. The real site video appears here once it is added.", "यह क्लिप प्रॉपर्टी के दृश्यों से बनी है। असली साइट वीडियो जुड़ते ही यहाँ दिखेगा।", "یہ کلپ پراپرٹی کے مناظر سے بنی ہے۔ اصل سائٹ ویڈیو شامل ہوتے ہی یہاں نظر آئے گی۔")}</p>
      </div>
    );
  }
  return (
    <div className="card clips">
      <h3 className="ct" style={{ marginTop: 0 }}>{"Video clips (" + vids.length + ")"}</h3>
      {vids.map((u, k) => (ytId(u) ? <div key={u} style={{ marginBottom: 12 }}><VideoBox url={u} title={title + " video " + (k + 1)} /></div>
        : isDirectVideo(u) ? <button key={u} type="button" className="vclip-open" aria-label={"Play full screen: " + title} onClick={() => openViewer({ video: u, title: title + " video " + (k + 1) })}><video className="vclip" muted playsInline preload="metadata" src={u + (u.indexOf("#") < 0 ? "#t=0.1" : "")} /><span className="vclip-play">▶</span></button>
        : <a key={u} className="btn btn-outline" style={{ marginBottom: 10 }} href={L(u)} target="_blank" rel="noopener noreferrer">{"▶ Watch video " + (k + 1) + " ↗"}</a>))}
    </div>
  );
}

export function MapCard({ p }) {
  const exact = hasExactMap(p);
  return (
    <div className="card mapcard">
      <div className="maphead"><span className="tile"><Icon name="pin" size={22} /></span><div><h3 className="ct" style={{ margin: 0 }}>{tr("Exact location")}</h3><p className="cb" style={{ margin: "4px 0 0" }}>{p.locality}, {p.block}, {p.district || "Saharsa"}, Bihar</p></div></div>
      {!exact && <p className="hint" style={{ marginTop: 10 }}>{tr("Only the area is shown here. Ask us on WhatsApp for the exact pin.")}</p>}
      <div className="stack" style={{ marginTop: 12 }}>
        <a className="btn btn-primary" href={L(mapLink(p))} target="_blank" rel="noopener noreferrer">📍 Open in Google Maps</a>
        <a className="btn btn-outline" href={L(mapDirections(p))} target="_blank" rel="noopener noreferrer">{tr("Get directions")}</a>
      </div>
    </div>
  );
}

export function BuyPage({ route, saved, toggle }) {
  const { lang, t } = useLang();
  const group = route.params.group || "";
  const [f, setF] = useState(() => (!route.parts[1] && !Object.keys(route.params).length && BUY_LAST.f) || { category: route.parts[1] || route.params.category || "", block: route.params.block || "", maxPrice: "", areaMin: "", areaUnit: "Katha", verified: false, sort: "new" });
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const firstRun = useRef(true);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  useEffect(() => { BUY_LAST.f = f; }, [f]);
  useEffect(() => { if (firstRun.current) { firstRun.current = false; return undefined; } setLoading(true); const id = setTimeout(() => setLoading(false), 420); return () => clearTimeout(id); }, [f.category, f.block, f.maxPrice, f.areaMin, f.areaUnit, f.verified, f.sort, group]);
  useEffect(() => { const id = setTimeout(() => replaceQuery(route.path, { category: route.parts[1] ? "" : f.category, block: f.block, group, max: f.maxPrice, areaMin: f.areaMin, unit: f.areaMin ? f.areaUnit : "", verified: f.verified ? "1" : "", sort: f.sort === "new" ? "" : f.sort }), 300); return () => clearTimeout(id); }, [route.path, route.parts, f, group]);
  const kat = getDb().settings.sqftPerKatha;
  const minSq = Number(f.areaMin) > 0 ? toSqft(f.areaMin, f.areaUnit, kat) : 0;
  const list = allProps().filter((p) => (!f.category || p.category === f.category) && (!group || (GROUPS[group] && GROUPS[group].includes(p.category))) && (!f.block || p.block === f.block) && (!f.verified || p.verified) && (!(Number(f.maxPrice) > 0) || p.price <= Number(f.maxPrice)) && (!minSq || (UNITS.includes(p.unit) && toSqft(p.area, p.unit, kat) >= minSq))).sort((a, b) => (f.sort === "low" ? a.price - b.price : f.sort === "high" ? b.price - a.price : 0));
  const chips = [];
  if (f.category) chips.push([catName(f.category, lang), () => set("category", "")]);
  if (group) chips.push([group, () => navigate("#/buy")]);
  if (f.block) chips.push([f.block, () => set("block", "")]);
  if (f.maxPrice) chips.push(["≤ " + fmtINR(f.maxPrice), () => set("maxPrice", "")]);
  if (f.areaMin) chips.push(["≥ " + f.areaMin + " " + f.areaUnit, () => set("areaMin", "")]);
  if (f.verified) chips.push([t("verified"), () => set("verified", false)]);
  return (
    <div className="wrap" style={{ paddingBottom: 48 }}>
      <PageHead pill={t("navBuy")} plain="Properties in " hl="Saharsa." />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 14 }}>
        <button type="button" className="btn btn-outline fbtn" style={{ height: 40 }} onClick={() => setOpen(true)}>Filters{chips.length ? " (" + chips.length + ")" : ""}</button>
        {chips.map(([label, clear]) => <button key={label} type="button" className="areachip" style={{ cursor: "pointer", textTransform: "capitalize" }} aria-label={"Remove filter " + label} onClick={clear}>{label} ✕</button>)}
      </div>
      <BuyCta />
      {open && <div className="fback" onPointerDown={() => setOpen(false)} aria-hidden="true" />}
      <div className="buylay">
        <aside className={"fsheet" + (open ? " open" : "")} aria-label={tr("Filters")}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}><b style={{ color: "var(--ink)" }}>{tr("Filters")}</b><button type="button" className="burger fclose" aria-label={t("close")} onClick={() => setOpen(false)}><Icon name="close" size={22} /></button></div>
          <SearchSelect id="f-cat" label={t("allCats")} value={f.category} options={[{ v: "", l: t("allCats") }].concat(CATEGORIES.map((c) => ({ v: c.slug, l: c.name[LANG_IDX[lang]] })))} onChange={(v) => set("category", v)} />
          <SearchSelect id="f-block" label={t("allBlocks")} value={f.block} options={[{ v: "", l: t("allBlocks") }].concat(BLOCKS_FILTER.map((b) => ({ v: b, l: b })))} onChange={(v) => set("block", v)} />
          <Field id="f-max" label={tr("Max price (₹)")}><input id="f-max" placeholder={ex("maxp")} className="inp" dir="ltr" inputMode="numeric" value={f.maxPrice} onChange={(e) => set("maxPrice", e.target.value.replace(/\D/g, ""))} /></Field>
          <Field id="f-area" label={tr("Minimum area (land units)")}><div style={{ display: "flex", gap: 8 }}><input id="f-area" placeholder={ex("minarea")} className="inp" dir="ltr" inputMode="decimal" value={f.areaMin} onChange={(e) => set("areaMin", e.target.value)} /><SearchSelect id="f-unit" compact ariaLabel="Area unit" value={f.areaUnit} options={UNITS} onChange={(v) => set("areaUnit", v)} /></div></Field>
          <SearchSelect id="f-sort" label={tr("Sort")} value={f.sort} options={[{ v: "new", l: "Newest" }, { v: "low", l: "Price: low to high" }, { v: "high", l: "Price: high to low" }]} onChange={(v) => set("sort", v)} />
          <label className="chk"><input id="f-ver" type="checkbox" checked={f.verified} onChange={(e) => set("verified", e.target.checked)} /> {tr("Verified only")}</label>
          <button type="button" className="btn btn-primary fclose" style={{ width: "100%", marginTop: 14 }} onClick={() => setOpen(false)}>Show {list.length} results</button>
        </aside>
        <div>
          {loading ? <div className="grid pgrid">{[0, 1, 2].map((k) => <div key={k} className="skel" aria-hidden="true" />)}</div>
            : list.length ? <div className="grid pgrid">{list.map((p) => <PropertyCard key={p.id} p={p} saved={saved.includes(p.id)} onToggleSave={toggle} />)}</div>
            : <div className="card" style={{ textAlign: "center" }}><p>{t("noResults")}</p><a className="btn btn-primary" style={{ marginBottom: 10 }} href={L("#/buy-request")}>{LANG_NOW.v === "hi" ? "अपनी ज़रूरत बताइए ›" : LANG_NOW.v === "ur" ? "اپنی ضرورت بتائیے ›" : "Tell us your requirement ›"}</a><a className="btn btn-wa" href={L(waLink(getDb().settings.whatsapp, waText("noresults", { parts: chips.map((c) => c[0]) }, lang)))} target="_blank" rel="noopener noreferrer">{t("askWa")}</a></div>}
        </div>
      </div>
    </div>
  );
}

export function VideoBox({ url, title }) {
  const id = ytId(url);
  if (!id) return null;
  return (
    <div className="vbox">
      <button type="button" className="vplay" aria-label={"Play full screen: " + title} onClick={() => openViewer({ video: url, title })}><span /></button>
    </div>
  );
}

export function VideoSection({ url }) {
  if (!ytId(url)) return null;
  return <Section id="sec-video"><h2 style={{ font: "800 clamp(26px,7vw,34px)/1.2 var(--display)", letterSpacing: "-.02em", color: "var(--ink)", textAlign: "center", margin: "0 0 20px" }}>{tr("See Earthix Property in Action")}</h2><VideoBox url={url} title="Earthix Property demo" /></Section>;
}

export function EmiBox({ price }) {
  const [down, setDown] = useState("20"), [rate, setRate] = useState("9"), [yrs, setYrs] = useState("15");
  const P0 = price * (1 - Math.min(Math.max(Number(down) || 0, 0), 90) / 100), r = Number(rate) / 1200, n = Number(yrs) * 12;
  const emi = P0 > 0 && n > 0 ? (r > 0 ? (P0 * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1) : P0 / n) : null;
  return (
    <div className="card" style={{ marginTop: 16 }}>
      <h3 className="ct" style={{ marginTop: 0 }}>{tr("Home-loan EMI estimate")}</h3>
      <Field id="de-down" label={tr("Down payment (%)")}><input id="de-down" placeholder={ex("down")} className="inp" dir="ltr" inputMode="decimal" value={down} onChange={(e) => setDown(e.target.value)} /></Field>
      <Field id="de-rate" label={tr("Interest rate (% per year)")}><input id="de-rate" placeholder={ex("rate")} className="inp" dir="ltr" inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
      <Field id="de-yrs" label={tr("Tenure (years)")}><input id="de-yrs" placeholder={ex("yrs")} className="inp" dir="ltr" inputMode="numeric" value={yrs} onChange={(e) => setYrs(e.target.value)} /></Field>
      <p className="price" style={{ marginTop: 14 }}>{emi ? fmtINR(Math.round(emi)) + " / month" : "–"}</p>
      <p style={{ fontSize: 12.5, margin: 0 }}>{tr("Estimate only. Your bank's offer will differ.")}</p>
    </div>
  );
}

export function DetailPage({ id, settings, saved, toggle, onBook, toast }) {
  const { lang, t } = useLang();
  const p = allProps().find((x) => x.id === id);
  const [gi, setGi] = useState(0);
  const imgs = p ? propImages(p) : [];
  const list = imgs.length ? imgs : [""];
  const n = list.length;
  const go = useCallback((d) => setGi((v) => (v + d + n) % n), [n]);
  const sw = useSwipe(() => go(1), () => go(-1));
  if (!p) return <NotFound />;
  const title = pick(p.title, lang);
  const isLand = UNITS.includes(p.unit);
  const sq = isLand ? toSqft(p.area, p.unit, settings.sqftPerKatha) : null;
  const ppk = isLand ? pricePerKatha(p.price, p.area, p.unit, settings.sqftPerKatha) : null;
  const related = allProps().filter((x) => x.id !== p.id && (x.category === p.category || x.block === p.block)).slice(0, 3);
  const share = async () => {
    const url = window.location.href;
    try { if (navigator.share) { await navigator.share({ title, url }); return; } } catch (e) { if (e && e.name === "AbortError") return; }
    try { await navigator.clipboard.writeText(url); toast("Link copied"); } catch (e) { toast(url); }
  };
  const msg = waText("property", { p, link: "https://" + WEB + "/" + lang + "/property/" + p.id, ppk }, lang);
  return (
    <div className="wrap" style={{ paddingBottom: 96, maxWidth: 720 }}>
      <p style={{ fontSize: 12.5, color: "var(--muted)" }}><a href={L("#/")}>{tr("Home")}</a> / <a href={L("#/buy")}>{t("navBuy")}</a> / {title}</p>
      <div className="slider" style={{ margin: "0 0 16px", width: "100%", aspectRatio: "4/3" }} onTouchStart={sw.onTouchStart} onTouchEnd={sw.onTouchEnd}>
        <div className="track" style={{ transform: "translateX(" + (LANG_NOW.v === "ur" ? gi : -gi) * 100 + "%)" }}>{list.map((src, k) => <div className="slide" key={k} role="button" tabIndex={0} style={{ cursor: "zoom-in" }} aria-label={title + " " + (k + 1) + " – " + L3(lang, "open full screen", "फ़ुल स्क्रीन में खोलें", "فل اسکرین میں کھولیں")} onClick={() => openViewer({ images: list, index: k, alt: title, title, category: p.category })} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openViewer({ images: list, index: k, alt: title, title, category: p.category }); } }}><SafeImg src={src} category={p.category} alt={title + " " + (k + 1)} width={1200} height={900} /></div>)}</div>
        <span className="tag" style={{ top: 10, insetInlineStart: 10 }}>{t("showcaseTag")}</span>
        {IMG_ILLUSTRATIVE && <span className="tag" style={{ bottom: 10, insetInlineStart: 10 }}>{t("illustrative")}</span>}
        {n > 1 && <button type="button" className="arrow l" aria-label={t("prev")} onClick={() => go(-1)}><Icon name="chevL" /></button>}
        {n > 1 && <button type="button" className="arrow r" aria-label={t("next")} onClick={() => go(1)}><Icon name="chevR" /></button>}
        {n > 1 && <div className="dots">{list.map((_, k) => <button key={k} type="button" className={k === gi ? "on" : ""} aria-label={"Photo " + (k + 1)} aria-pressed={k === gi} onClick={() => setGi(k)} />)}</div>}
      </div>
      <Thumbs list={list} cur={gi} onPick={setGi} category={p.category} title={title} />
      <PropDetailsCard p={p} settings={settings}
        head={<>
          <div className="price">{fmtINR(p.price)}{priceSuffix(p) ? t("perMonth") : ""}</div>
          {ppk && <div className="pdppk">≈ {fmtINR(Math.round(ppk))} {t("perKatha")}</div>}
          <h1 className="pdtitle">{title}</h1>
          <div className="loc"><Icon name="pin" size={14} />{p.locality}, {p.block}</div>
          <span className="mini">{catName(p.category, lang)}</span>{p.verified && <span className="mini v"><Icon name="shield" size={12} />{t("verified")}</span>}
        </>}
        foot={<PropActions p={p}>
          <div className="pc-act2">
            <button type="button" className="btn btn-outline" aria-pressed={saved.includes(p.id)} onClick={() => toggle(p.id)}><Icon name="heart" size={18} />{t("save")}</button>
            <button type="button" className="btn btn-outline" onClick={share}>{tr("Share")}</button>
          </div>
        </PropActions>} />
      <MediaClips p={p} title={title} />
      <MapCard p={p} />
      {EMI_CATEGORIES.includes(p.category) && p.listingType !== "rent" && <EmiBox price={p.price} />}
      {related.length > 0 && <div><h3 className="ct">{tr("Related properties")}</h3><div className="grid pgrid">{related.map((x) => <PropertyCard key={x.id} p={x} saved={saved.includes(x.id)} onToggleSave={toggle} />)}</div></div>}
    </div>
  );
}

export function EmiCard() {
  const [amt, setAmt] = useState("2500000"), [rate, setRate] = useState("9"), [yrs, setYrs] = useState("15");
  const P0 = Number(amt), r = Number(rate) / 1200, n = Number(yrs) * 12;
  const emi = P0 > 0 && n > 0 ? (r > 0 ? (P0 * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1) : P0 / n) : null;
  return (
    <form className="card" style={{ marginTop: 16 }} onSubmit={(e) => e.preventDefault()}>
      <h3 className="ct">{tr("EMI Calculator")}</h3>
      <Field id="emi-amt" label={tr("Loan amount (₹)")}><input id="emi-amt" placeholder={ex("amt")} className="inp" dir="ltr" inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} /></Field>
      <Field id="emi-rate" label={tr("Interest rate (% per year)")}><input id="emi-rate" placeholder={ex("rate")} className="inp" dir="ltr" inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
      <Field id="emi-yrs" label={tr("Tenure (years)")}><input id="emi-yrs" placeholder={ex("yrs")} className="inp" dir="ltr" inputMode="numeric" value={yrs} onChange={(e) => setYrs(e.target.value)} /></Field>
      <p className="price" style={{ marginTop: 14 }}>{emi ? fmtINR(Math.round(emi)) + " / month" : "–"}</p>
    </form>
  );
}

export const PropertyCard = React.memo(PropertyCardInner);
